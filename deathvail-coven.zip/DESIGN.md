# Design Brief: deathVail Coven Music Hub

## Tone & Purpose
Dark, premium music discovery platform for deathVail Coven. Industrial/brutalist aesthetic with luxury finesse. YouTube-inspired layout with heavy music energy.

## Visual Direction
Deep blacks (`0.12 0 0`), dark charcoal cards (`0.18 0 0`), electric crimson red accents (`0.55 0.22 25`). Minimal radius (4px), sharp edges, thin borders. High contrast between zones.

## Typography
- **Display**: Fraunces (serif, editorial, distinctive)
- **Body**: DM Sans (modern, neutral, legible)
- **Mono**: JetBrains Mono (technical elements, timestamps)

## Color Palette

| Token | Light | Dark | Usage |
|-------|-------|------|-------|
| Background | `0.99 0 0` | `0.12 0 0` | Page background |
| Card | `1.0 0 0` | `0.18 0 0` | Content cards, surfaces |
| Foreground | `0.15 0 0` | `0.94 0 0` | Text, primary copy |
| Primary (Crimson) | `0.55 0.22 25` | `0.55 0.22 25` | Interactive, buttons, logo accent |
| Accent | `0.48 0.18 30` | `0.62 0.2 28` | Highlights, hover states |
| Muted | `0.95 0 0` | `0.35 0 0` | Secondary text, disabled |
| Border | `0.9 0 0` | `0.25 0 0` | Lines, dividers, card outlines |
| Destructive | `0.55 0.22 25` | `0.65 0.19 22` | Warnings, delete actions |

## Structural Zones

| Zone | Treatment | Details |
|------|-----------|---------|
| Header | `bg-card` + `border-b` + accent stripe | Crimson 2px top bar, contains deathVail Coven logo + search + user menu |
| Sidebar | `bg-background` + `border-r` | Elevated navigation, category links |
| Content Grid | `bg-background` | Cards in `bg-card` with subtle borders |
| Modals | `bg-card` | Song detail overlays, no full-page blur (snappy) |
| Footer | `bg-card` + `border-t` | If needed, consistent with header treatment |

## Components & Patterns
- **Cards**: Sharp borders (`border-border`), no shadow or minimal shadow
- **Buttons**: Crimson primary (`bg-primary`), secondary with outline, crisp hover state
- **Search bar**: Input in `bg-secondary`, text in `text-foreground`
- **Song thumbnails**: Grid layout with title, artist, duration in monospace
- **Member tabs**: Underline indicator in primary color

## Motion
Smooth transitions on hover/focus (0.3s cubic-bezier). No bouncing or overdone animations. Minimize distraction from content.

## Signature Detail
Thin crimson accent stripe atop header and key interactive elements. Editorial typography (Fraunces) for discography and titles. Brutalist edge without coldness — premium music hub feel.

## Constraints
- No generic AI aesthetics (no purple gradients, no safe blue)
- Dark mode only (heavy music aesthetic)
- Preserve deathVail Coven branding prominence throughout
- YouTube-inspired layout but darker, more premium
- Sharp edges, minimal padding where possible
