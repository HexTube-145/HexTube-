import List "mo:core/List";
import Runtime "mo:core/Runtime";
import Principal "mo:core/Principal";
import Time "mo:core/Time";
import Nat "mo:core/Nat";
import CommonTypes "../types/common";
import ContentTypes "../types/content";

module {
  public type ContentStore = List.List<ContentTypes.Content>;

  public func listAll(contents : ContentStore) : [ContentTypes.Content] {
    let sorted = contents.sort(func(a, b) = if (a.createdAt > b.createdAt) #less else if (a.createdAt < b.createdAt) #greater else #equal);
    sorted.toArray();
  };

  public func getById(contents : ContentStore, id : CommonTypes.ContentId) : ?ContentTypes.Content {
    contents.find(func(c) = Nat.equal(c.id, id));
  };

  public func listByMember(contents : ContentStore, uploader : Principal) : [ContentTypes.Content] {
    let filtered = contents.filter(func(c) = Principal.equal(c.uploaderId, uploader));
    let sorted = filtered.sort(func(a, b) = if (a.createdAt > b.createdAt) #less else if (a.createdAt < b.createdAt) #greater else #equal);
    sorted.toArray();
  };

  public func listByType(contents : ContentStore, contentType : ContentTypes.ContentType) : [ContentTypes.Content] {
    let filtered = contents.filter(func(c) = c.contentType == contentType);
    let sorted = filtered.sort(func(a, b) = if (a.createdAt > b.createdAt) #less else if (a.createdAt < b.createdAt) #greater else #equal);
    sorted.toArray();
  };

  public func add(
    contents : ContentStore,
    nextId : Nat,
    input : ContentTypes.ContentInput,
    caller : Principal,
  ) : CommonTypes.ContentId {
    let id = nextId;
    let item : ContentTypes.Content = {
      id;
      title = input.title;
      description = input.description;
      contentType = input.contentType;
      uploaderId = caller;
      uploaderName = input.uploaderName;
      coverArtUrl = input.coverArtUrl;
      mediaUrl = input.mediaUrl;
      duration = input.duration;
      releaseDate = input.releaseDate;
      createdAt = Time.now();
    };
    contents.add(item);
    id;
  };

  public func update(
    contents : ContentStore,
    id : CommonTypes.ContentId,
    input : ContentTypes.ContentInput,
    caller : Principal,
    isAdmin : Bool,
  ) : Bool {
    switch (contents.findIndex(func(c) = Nat.equal(c.id, id))) {
      case null false;
      case (?idx) {
        let existing = contents.at(idx);
        if (not isAdmin and not Principal.equal(existing.uploaderId, caller)) {
          Runtime.trap("Unauthorized: Only the uploader or an admin can update this content");
        };
        let updated : ContentTypes.Content = {
          existing with
          title = input.title;
          description = input.description;
          contentType = input.contentType;
          uploaderName = input.uploaderName;
          coverArtUrl = input.coverArtUrl;
          mediaUrl = input.mediaUrl;
          duration = input.duration;
          releaseDate = input.releaseDate;
        };
        contents.put(idx, updated);
        true;
      };
    };
  };

  public func delete(
    contents : ContentStore,
    id : CommonTypes.ContentId,
    caller : Principal,
    isAdmin : Bool,
  ) : Bool {
    switch (contents.findIndex(func(c) = Nat.equal(c.id, id))) {
      case null false;
      case (?idx) {
        let existing = contents.at(idx);
        if (not isAdmin and not Principal.equal(existing.uploaderId, caller)) {
          Runtime.trap("Unauthorized: Only the uploader or an admin can delete this content");
        };
        // Remove by rebuilding list without the item
        let before = contents.sliceToArray(0, idx);
        let after = contents.sliceToArray(idx + 1, contents.size());
        contents.clear();
        for (item in before.values()) { contents.add(item) };
        for (item in after.values()) { contents.add(item) };
        true;
      };
    };
  };

  public func countByMember(contents : ContentStore, uploader : Principal) : Nat {
    contents.filter(func(c) = Principal.equal(c.uploaderId, uploader)).size();
  };
};
