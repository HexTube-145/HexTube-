import List "mo:core/List";
import Nat "mo:core/Nat";
import Text "mo:core/Text";
import Order "mo:core/Order";
import Time "mo:core/Time";
import CommonTypes "../types/common";
import DiscographyTypes "../types/discography";

module {
  public type ReleaseStore = List.List<DiscographyTypes.Release>;

  func compareReleaseDates(a : DiscographyTypes.Release, b : DiscographyTypes.Release) : Order.Order {
    Text.compare(b.releaseDate, a.releaseDate)
  };

  public func listAll(releases : ReleaseStore) : [DiscographyTypes.Release] {
    let sorted = releases.sort(compareReleaseDates);
    sorted.toArray();
  };

  public func listByType(releases : ReleaseStore, releaseType : DiscographyTypes.ReleaseType) : [DiscographyTypes.Release] {
    let filtered = releases.filter(func(r) = r.releaseType == releaseType);
    let sorted = filtered.sort(compareReleaseDates);
    sorted.toArray();
  };

  public func getById(releases : ReleaseStore, id : CommonTypes.ReleaseId) : ?DiscographyTypes.Release {
    releases.find(func(r) = Nat.equal(r.id, id));
  };

  public func add(
    releases : ReleaseStore,
    nextId : Nat,
    input : DiscographyTypes.ReleaseInput,
  ) : CommonTypes.ReleaseId {
    let id = nextId;
    let item : DiscographyTypes.Release = {
      id;
      title = input.title;
      releaseType = input.releaseType;
      releaseDate = input.releaseDate;
      coverArtUrl = input.coverArtUrl;
      trackIds = input.trackIds;
      createdAt = Time.now();
    };
    releases.add(item);
    id;
  };

  public func update(
    releases : ReleaseStore,
    id : CommonTypes.ReleaseId,
    input : DiscographyTypes.ReleaseInput,
  ) : Bool {
    switch (releases.findIndex(func(r) = Nat.equal(r.id, id))) {
      case null false;
      case (?idx) {
        let existing = releases.at(idx);
        let updated : DiscographyTypes.Release = {
          existing with
          title = input.title;
          releaseType = input.releaseType;
          releaseDate = input.releaseDate;
          coverArtUrl = input.coverArtUrl;
          trackIds = input.trackIds;
        };
        releases.put(idx, updated);
        true;
      };
    };
  };

  public func delete(releases : ReleaseStore, id : CommonTypes.ReleaseId) : Bool {
    switch (releases.findIndex(func(r) = Nat.equal(r.id, id))) {
      case null false;
      case (?idx) {
        let before = releases.sliceToArray(0, idx);
        let after = releases.sliceToArray(idx + 1, releases.size());
        releases.clear();
        for (item in before.values()) { releases.add(item) };
        for (item in after.values()) { releases.add(item) };
        true;
      };
    };
  };
};
