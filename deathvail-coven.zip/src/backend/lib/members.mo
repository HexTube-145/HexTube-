import List "mo:core/List";
import Runtime "mo:core/Runtime";
import Principal "mo:core/Principal";
import Time "mo:core/Time";
import MemberTypes "../types/members";
import CommonTypes "../types/common";

module {
  public type MemberStore = List.List<MemberTypes.MemberProfile>;

  public func listAll(members : MemberStore) : [MemberTypes.MemberProfile] {
    members.toArray();
  };

  public func getByPrincipal(members : MemberStore, principalId : Principal) : ?MemberTypes.MemberProfile {
    members.find(func(m) = Principal.equal(m.principalId, principalId));
  };

  public func upsert(
    members : MemberStore,
    principalId : Principal,
    memberName : Text,
    joinedAt : CommonTypes.Timestamp,
  ) : () {
    switch (members.findIndex(func(m) = Principal.equal(m.principalId, principalId))) {
      case null {
        let profile : MemberTypes.MemberProfile = {
          principalId;
          memberName;
          joinedAt;
          uploadCount = 0;
        };
        members.add(profile);
      };
      case (?idx) {
        let existing = members.at(idx);
        let updated : MemberTypes.MemberProfile = {
          existing with memberName;
        };
        members.put(idx, updated);
      };
    };
  };

  public func incrementUploadCount(members : MemberStore, principalId : Principal) : () {
    switch (members.findIndex(func(m) = Principal.equal(m.principalId, principalId))) {
      case null ();
      case (?idx) {
        let existing = members.at(idx);
        let updated : MemberTypes.MemberProfile = {
          existing with uploadCount = existing.uploadCount + 1;
        };
        members.put(idx, updated);
      };
    };
  };

  public func decrementUploadCount(members : MemberStore, principalId : Principal) : () {
    switch (members.findIndex(func(m) = Principal.equal(m.principalId, principalId))) {
      case null ();
      case (?idx) {
        let existing = members.at(idx);
        let count = if (existing.uploadCount > 0) existing.uploadCount - 1 else 0;
        let updated : MemberTypes.MemberProfile = {
          existing with uploadCount = count;
        };
        members.put(idx, updated);
      };
    };
  };
};
