import List "mo:core/List";
import Principal "mo:core/Principal";
import Text "mo:core/Text";
import Runtime "mo:core/Runtime";

// authorization: custom principal-based admin system
// Admin IDs stored as Text to avoid blob_of_principal at init time.

import ContentMixin "mixins/content-api";
import DiscographyMixin "mixins/discography-api";
import MembersMixin "mixins/members-api";
import ContentLib "lib/content";
import DiscographyLib "lib/discography";
import MemberLib "lib/members";

actor {
  // Store admin principals as Text — avoids Principal comparison at canister init
  var adminIds : List.List<Text> = List.empty();
  var initialized : Bool = false;

  func isAdminPrincipal(p : Principal) : Bool {
    let t = p.toText();
    adminIds.find(func(a) = Text.equal(a, t)) != null;
  };

  /// Must be called once by the deployer after canister creation to register as first admin.
  public shared ({ caller }) func initAdmins() : async () {
    if (initialized) {
      Runtime.trap("Already initialized");
    };
    adminIds.add(caller.toText());
    initialized := true;
  };

  /// Check if a principal is an admin
  public query func isAdmin(p : Principal) : async Bool {
    isAdminPrincipal(p);
  };

  /// Add an admin — existing admin only
  public shared ({ caller }) func addAdmin(p : Principal) : async () {
    if (not isAdminPrincipal(caller)) {
      Runtime.trap("Unauthorized: Only admins can add other admins");
    };
    let t = p.toText();
    if (adminIds.find(func(a) = Text.equal(a, t)) == null) {
      adminIds.add(t);
    };
  };

  /// Remove an admin — existing admin only; cannot remove yourself if last admin
  public shared ({ caller }) func removeAdmin(p : Principal) : async () {
    if (not isAdminPrincipal(caller)) {
      Runtime.trap("Unauthorized: Only admins can remove admins");
    };
    let t = p.toText();
    if (Text.equal(t, caller.toText()) and adminIds.size() == 1) {
      Runtime.trap("Cannot remove the last admin");
    };
    adminIds := adminIds.filter(func(a) = not Text.equal(a, t));
  };

  /// List all admins — admin only
  public query ({ caller }) func listAdmins() : async [Principal] {
    if (not isAdminPrincipal(caller)) {
      Runtime.trap("Unauthorized: Only admins can list admins");
    };
    adminIds.toArray().map(func(t : Text) : Principal = Principal.fromText(t));
  };

  // Domain state — List-based stores: no comparison/hash at init time
  let contents : ContentLib.ContentStore = List.empty();
  let releases : DiscographyLib.ReleaseStore = List.empty();
  let members : MemberLib.MemberStore = List.empty();

  // ID counters as mutable ref objects passed to mixins
  let contentIdRef = { var value : Nat = 0 };
  let releaseIdRef = { var value : Nat = 0 };

  // Domain mixins — pass adminList check function directly
  include ContentMixin(isAdminPrincipal, contents, members, contentIdRef);
  include DiscographyMixin(isAdminPrincipal, releases, contents, releaseIdRef);
  include MembersMixin(isAdminPrincipal, members);
};
