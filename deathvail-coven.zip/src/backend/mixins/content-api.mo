import Runtime "mo:core/Runtime";
import Principal "mo:core/Principal";
import Time "mo:core/Time";
import CommonTypes "../types/common";
import ContentTypes "../types/content";
import ContentLib "../lib/content";
import MemberLib "../lib/members";

mixin (
  isAdminPrincipal : Principal -> Bool,
  contents : ContentLib.ContentStore,
  members : MemberLib.MemberStore,
  nextContentId : { var value : Nat },
) {
  /// List all content across all members, sorted by createdAt descending
  public query func listAllContent() : async [ContentTypes.Content] {
    ContentLib.listAll(contents);
  };

  /// Get a single content item by ID
  public query func getContent(id : CommonTypes.ContentId) : async ?ContentTypes.Content {
    ContentLib.getById(contents, id);
  };

  /// List content uploaded by a specific member
  public query func listContentByMember(uploader : Principal) : async [ContentTypes.Content] {
    ContentLib.listByMember(contents, uploader);
  };

  /// List content by type (song, snippet, photo, etc.)
  public query func listContentByType(contentType : ContentTypes.ContentType) : async [ContentTypes.Content] {
    ContentLib.listByType(contents, contentType);
  };

  /// Upload new content — admins only
  public shared ({ caller }) func uploadContent(input : ContentTypes.ContentInput) : async CommonTypes.ContentId {
    if (not isAdminPrincipal(caller)) {
      Runtime.trap("Unauthorized: Only admins can upload content");
    };
    // Ensure member profile exists
    MemberLib.upsert(members, caller, input.uploaderName, Time.now());
    let id = ContentLib.add(contents, nextContentId.value, input, caller);
    nextContentId.value += 1;
    MemberLib.incrementUploadCount(members, caller);
    id;
  };

  /// Update existing content — uploader or admin
  public shared ({ caller }) func updateContent(id : CommonTypes.ContentId, input : ContentTypes.ContentInput) : async Bool {
    let isAdminCaller = isAdminPrincipal(caller);
    if (not isAdminCaller) {
      switch (ContentLib.getById(contents, id)) {
        case null { return false };
        case (?c) {
          if (not Principal.equal(c.uploaderId, caller)) {
            Runtime.trap("Unauthorized: Only the uploader or an admin can update this content");
          };
        };
      };
    };
    ContentLib.update(contents, id, input, caller, isAdminCaller);
  };

  /// Delete content — uploader or admin
  public shared ({ caller }) func deleteContent(id : CommonTypes.ContentId) : async Bool {
    let isAdminCaller = isAdminPrincipal(caller);
    if (not isAdminCaller) {
      switch (ContentLib.getById(contents, id)) {
        case null { return false };
        case (?c) {
          if (not Principal.equal(c.uploaderId, caller)) {
            Runtime.trap("Unauthorized: Only the uploader or an admin can delete this content");
          };
        };
      };
    };
    let uploaderOpt = switch (ContentLib.getById(contents, id)) {
      case null null;
      case (?c) ?c.uploaderId;
    };
    let deleted = ContentLib.delete(contents, id, caller, isAdminCaller);
    if (deleted) {
      switch (uploaderOpt) {
        case (?uploader) MemberLib.decrementUploadCount(members, uploader);
        case null ();
      };
    };
    deleted;
  };
};
