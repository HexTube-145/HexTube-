import Runtime "mo:core/Runtime";
import List "mo:core/List";
import Principal "mo:core/Principal";
import CommonTypes "../types/common";
import DiscographyTypes "../types/discography";
import ContentTypes "../types/content";
import DiscographyLib "../lib/discography";
import ContentLib "../lib/content";

mixin (
  isAdminPrincipal : Principal -> Bool,
  releases : DiscographyLib.ReleaseStore,
  contents : ContentLib.ContentStore,
  nextReleaseId : { var value : Nat },
) {
  /// List all releases (albums, EPs, singles), sorted by releaseDate descending
  public query func listReleases() : async [DiscographyTypes.Release] {
    DiscographyLib.listAll(releases);
  };

  /// List releases filtered by type
  public query func listReleasesByType(releaseType : DiscographyTypes.ReleaseType) : async [DiscographyTypes.Release] {
    DiscographyLib.listByType(releases, releaseType);
  };

  /// Get a single release by ID
  public query func getRelease(id : CommonTypes.ReleaseId) : async ?DiscographyTypes.Release {
    DiscographyLib.getById(releases, id);
  };

  /// Get all tracks for a release with full content details
  public query func getReleaseTracks(id : CommonTypes.ReleaseId) : async [ContentTypes.Content] {
    switch (DiscographyLib.getById(releases, id)) {
      case null [];
      case (?release) {
        let tracks = List.empty<ContentTypes.Content>();
        for (trackId in release.trackIds.values()) {
          switch (ContentLib.getById(contents, trackId)) {
            case (?content) tracks.add(content);
            case null ();
          };
        };
        tracks.toArray();
      };
    };
  };

  /// Create a new release — admin only
  public shared ({ caller }) func createRelease(input : DiscographyTypes.ReleaseInput) : async CommonTypes.ReleaseId {
    if (not isAdminPrincipal(caller)) {
      Runtime.trap("Unauthorized: Only admins can create releases");
    };
    let id = DiscographyLib.add(releases, nextReleaseId.value, input);
    nextReleaseId.value += 1;
    id;
  };

  /// Update a release — admin only
  public shared ({ caller }) func updateRelease(id : CommonTypes.ReleaseId, input : DiscographyTypes.ReleaseInput) : async Bool {
    if (not isAdminPrincipal(caller)) {
      Runtime.trap("Unauthorized: Only admins can update releases");
    };
    DiscographyLib.update(releases, id, input);
  };

  /// Delete a release — admin only
  public shared ({ caller }) func deleteRelease(id : CommonTypes.ReleaseId) : async Bool {
    if (not isAdminPrincipal(caller)) {
      Runtime.trap("Unauthorized: Only admins can delete releases");
    };
    DiscographyLib.delete(releases, id);
  };
};
