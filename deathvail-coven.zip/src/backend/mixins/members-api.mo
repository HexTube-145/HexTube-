import Runtime "mo:core/Runtime";
import Principal "mo:core/Principal";
import Time "mo:core/Time";
import MemberTypes "../types/members";
import MemberLib "../lib/members";

mixin (
  isAdminPrincipal : Principal -> Bool,
  members : MemberLib.MemberStore,
) {
  /// List all member profiles — public query
  public query func listMembers() : async [MemberTypes.MemberProfile] {
    MemberLib.listAll(members);
  };

  /// Get a specific member's profile — public query
  public query func getMemberProfile(principalId : Principal) : async ?MemberTypes.MemberProfile {
    MemberLib.getByPrincipal(members, principalId);
  };

  /// Register or update own member profile — admins only
  public shared ({ caller }) func saveMemberProfile(memberName : Text) : async () {
    if (not isAdminPrincipal(caller)) {
      Runtime.trap("Unauthorized: Only admins can save a member profile");
    };
    MemberLib.upsert(members, caller, memberName, Time.now());
  };
};
