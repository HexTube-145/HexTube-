module {
  public type ContentId = Nat;
  public type ReleaseId = Nat;
  public type Timestamp = Int;
};
