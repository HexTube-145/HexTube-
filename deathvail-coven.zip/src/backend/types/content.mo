import CommonTypes "common";

module {
  public type ContentType = {
    #song;
    #snippet;
    #leak;
    #photo;
    #video;
  };

  public type Content = {
    id : CommonTypes.ContentId;
    title : Text;
    description : Text;
    contentType : ContentType;
    uploaderId : Principal;
    uploaderName : Text;
    coverArtUrl : Text;
    mediaUrl : Text;
    duration : ?Nat; // seconds, only for song/snippet
    releaseDate : ?Text; // ISO date string, only for song/snippet
    createdAt : CommonTypes.Timestamp;
  };

  public type ContentInput = {
    title : Text;
    description : Text;
    contentType : ContentType;
    uploaderName : Text;
    coverArtUrl : Text;
    mediaUrl : Text;
    duration : ?Nat;
    releaseDate : ?Text;
  };
};
