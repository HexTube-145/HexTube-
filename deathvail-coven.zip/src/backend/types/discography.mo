import CommonTypes "common";

module {
  public type ReleaseType = {
    #album;
    #ep;
    #single;
  };

  public type Release = {
    id : CommonTypes.ReleaseId;
    title : Text;
    releaseType : ReleaseType;
    releaseDate : Text; // ISO date string
    coverArtUrl : Text;
    trackIds : [CommonTypes.ContentId]; // ordered list of song IDs
    createdAt : CommonTypes.Timestamp;
  };

  public type ReleaseInput = {
    title : Text;
    releaseType : ReleaseType;
    releaseDate : Text;
    coverArtUrl : Text;
    trackIds : [CommonTypes.ContentId];
  };
};
