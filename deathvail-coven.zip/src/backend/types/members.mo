import CommonTypes "common";

module {
  public type MemberProfile = {
    principalId : Principal;
    memberName : Text;
    joinedAt : CommonTypes.Timestamp;
    uploadCount : Nat;
  };
};
