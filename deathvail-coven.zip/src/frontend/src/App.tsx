import { Skeleton } from "@/components/ui/skeleton";
import {
  RouterProvider,
  createRootRoute,
  createRoute,
  createRouter,
} from "@tanstack/react-router";
import { Suspense, lazy } from "react";
import { Layout } from "./components/Layout";

// Lazy-load pages
const HomePage = lazy(() =>
  import("./pages/Home").then((m) => ({ default: m.HomePage })),
);
const LatestPage = lazy(() =>
  import("./pages/Latest").then((m) => ({ default: m.LatestPage })),
);
const ReleasesPage = lazy(() =>
  import("./pages/Releases").then((m) => ({ default: m.ReleasesPage })),
);
const SnippetsPage = lazy(() =>
  import("./pages/Snippets").then((m) => ({ default: m.SnippetsPage })),
);
const PhotosPage = lazy(() =>
  import("./pages/Photos").then((m) => ({ default: m.PhotosPage })),
);
const MembersPage = lazy(() =>
  import("./pages/Members").then((m) => ({ default: m.MembersPage })),
);
const CovenPage = lazy(() =>
  import("./pages/Coven").then((m) => ({ default: m.CovenPage })),
);
const MemberPage = lazy(() =>
  import("./pages/MemberDetail").then((m) => ({ default: m.MemberPage })),
);
const ReleasePage = lazy(() =>
  import("./pages/ReleaseDetail").then((m) => ({ default: m.ReleasePage })),
);
const SearchPage = lazy(() =>
  import("./pages/Search").then((m) => ({ default: m.SearchPage })),
);
const AdminPage = lazy(() =>
  import("./pages/Admin").then((m) => ({ default: m.AdminPage })),
);
const UploadPage = lazy(() =>
  import("./pages/Upload").then((m) => ({ default: m.UploadPage })),
);

const SKEL_IDS = ["a", "b", "c", "d", "e", "f", "g", "h"];

function PageLoader() {
  return (
    <div className="p-6 space-y-4">
      <Skeleton className="h-8 w-64" />
      <Skeleton className="h-4 w-96" />
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
        {SKEL_IDS.map((id) => (
          <Skeleton key={id} className="h-40 rounded" />
        ))}
      </div>
    </div>
  );
}

// Root route wraps everything with Layout
const rootRoute = createRootRoute({
  component: Layout,
});

const indexRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/",
  component: () => (
    <Suspense fallback={<PageLoader />}>
      <HomePage />
    </Suspense>
  ),
});

const latestRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/latest",
  component: () => (
    <Suspense fallback={<PageLoader />}>
      <LatestPage />
    </Suspense>
  ),
});

const releasesRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/releases",
  component: () => (
    <Suspense fallback={<PageLoader />}>
      <ReleasesPage />
    </Suspense>
  ),
});

const releaseDetailRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/releases/$releaseId",
  component: () => (
    <Suspense fallback={<PageLoader />}>
      <ReleasePage />
    </Suspense>
  ),
});

const snippetsRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/snippets",
  component: () => (
    <Suspense fallback={<PageLoader />}>
      <SnippetsPage />
    </Suspense>
  ),
});

const photosRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/photos",
  component: () => (
    <Suspense fallback={<PageLoader />}>
      <PhotosPage />
    </Suspense>
  ),
});

const membersRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/members",
  validateSearch: (search: Record<string, unknown>) => ({
    member: typeof search.member === "string" ? search.member : "",
  }),
  component: () => (
    <Suspense fallback={<PageLoader />}>
      <MembersPage />
    </Suspense>
  ),
});

const memberDetailRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/members/$handle",
  component: () => (
    <Suspense fallback={<PageLoader />}>
      <MemberPage />
    </Suspense>
  ),
});

const covenRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/coven",
  component: () => (
    <Suspense fallback={<PageLoader />}>
      <CovenPage />
    </Suspense>
  ),
});

const searchRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/search",
  validateSearch: (search: Record<string, unknown>) => ({
    q: typeof search.q === "string" ? search.q : "",
  }),
  component: () => (
    <Suspense fallback={<PageLoader />}>
      <SearchPage />
    </Suspense>
  ),
});

const adminRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/admin",
  component: () => (
    <Suspense fallback={<PageLoader />}>
      <AdminPage />
    </Suspense>
  ),
});

const uploadRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/upload",
  component: () => (
    <Suspense fallback={<PageLoader />}>
      <UploadPage />
    </Suspense>
  ),
});

const routeTree = rootRoute.addChildren([
  indexRoute,
  latestRoute,
  releasesRoute,
  releaseDetailRoute,
  snippetsRoute,
  photosRoute,
  membersRoute,
  memberDetailRoute,
  covenRoute,
  searchRoute,
  adminRoute,
  uploadRoute,
]);

const router = createRouter({ routeTree });

declare module "@tanstack/react-router" {
  interface Register {
    router: typeof router;
  }
}

export default function App() {
  return <RouterProvider router={router} />;
}
