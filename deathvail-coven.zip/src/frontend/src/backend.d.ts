import type { Principal } from "@icp-sdk/core/principal";
export interface Some<T> {
    __kind__: "Some";
    value: T;
}
export interface None {
    __kind__: "None";
}
export type Option<T> = Some<T> | None;
export type Timestamp = bigint;
export interface Release {
    id: ReleaseId;
    title: string;
    createdAt: Timestamp;
    coverArtUrl: string;
    trackIds: Array<ContentId>;
    releaseDate: string;
    releaseType: ReleaseType;
}
export type ContentId = bigint;
export interface Content {
    id: ContentId;
    title: string;
    duration?: bigint;
    uploaderName: string;
    contentType: ContentType;
    createdAt: Timestamp;
    description: string;
    mediaUrl: string;
    coverArtUrl: string;
    releaseDate?: string;
    uploaderId: Principal;
}
export type ReleaseId = bigint;
export interface ContentInput {
    title: string;
    duration?: bigint;
    uploaderName: string;
    contentType: ContentType;
    description: string;
    mediaUrl: string;
    coverArtUrl: string;
    releaseDate?: string;
}
export interface ReleaseInput {
    title: string;
    coverArtUrl: string;
    trackIds: Array<ContentId>;
    releaseDate: string;
    releaseType: ReleaseType;
}
export interface MemberProfile {
    joinedAt: Timestamp;
    uploadCount: bigint;
    memberName: string;
    principalId: Principal;
}
export enum ContentType {
    video = "video",
    leak = "leak",
    song = "song",
    snippet = "snippet",
    photo = "photo"
}
export enum ReleaseType {
    ep = "ep",
    album = "album",
    single = "single"
}
export interface backendInterface {
    /**
     * / Add an admin — existing admin only
     */
    addAdmin(p: Principal): Promise<void>;
    createRelease(input: ReleaseInput): Promise<ReleaseId>;
    deleteContent(id: ContentId): Promise<boolean>;
    deleteRelease(id: ReleaseId): Promise<boolean>;
    getContent(id: ContentId): Promise<Content | null>;
    getMemberProfile(principalId: Principal): Promise<MemberProfile | null>;
    /**
     * / Must be called once by the deployer after canister creation to register as first admin.
     */
    getRelease(id: ReleaseId): Promise<Release | null>;
    getReleaseTracks(id: ReleaseId): Promise<Array<Content>>;
    /**
     * / Must be called once by the deployer after canister creation to register as first admin.
     */
    initAdmins(): Promise<void>;
    /**
     * / Check if a principal is an admin
     */
    isAdmin(p: Principal): Promise<boolean>;
    /**
     * / List all admins — admin only
     */
    listAdmins(): Promise<Array<Principal>>;
    listAllContent(): Promise<Array<Content>>;
    listContentByMember(uploader: Principal): Promise<Array<Content>>;
    listContentByType(contentType: ContentType): Promise<Array<Content>>;
    listMembers(): Promise<Array<MemberProfile>>;
    listReleases(): Promise<Array<Release>>;
    listReleasesByType(releaseType: ReleaseType): Promise<Array<Release>>;
    /**
     * / Remove an admin — existing admin only; cannot remove yourself if last admin
     */
    removeAdmin(p: Principal): Promise<void>;
    saveMemberProfile(memberName: string): Promise<void>;
    updateContent(id: ContentId, input: ContentInput): Promise<boolean>;
    updateRelease(id: ReleaseId, input: ReleaseInput): Promise<boolean>;
    /**
     * / Check if a principal is an admin
     */
    uploadContent(input: ContentInput): Promise<ContentId>;
}
