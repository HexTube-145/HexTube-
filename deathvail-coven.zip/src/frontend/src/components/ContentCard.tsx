import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "@tanstack/react-router";
import { Camera, FileAudio, Film, Headphones, Music, Play } from "lucide-react";
import type { ContentItem, ContentType } from "../types";

// ─── Type config ─────────────────────────────────────────────────────────────
type TypeConfig = {
  label: string;
  Icon: React.FC<{ className?: string }>;
  colorClass: string;
};

const TYPE_CONFIG: Record<ContentType, TypeConfig> = {
  song: {
    label: "Song",
    Icon: Music,
    colorClass: "bg-primary/20 text-primary border-primary/40",
  },
  snippet: {
    label: "Snippet",
    Icon: Headphones,
    colorClass: "bg-accent/20 text-accent border-accent/40",
  },
  leak: {
    label: "Leak",
    Icon: FileAudio,
    colorClass: "bg-destructive/20 text-destructive border-destructive/40",
  },
  photo: {
    label: "Photo",
    Icon: Camera,
    colorClass: "bg-secondary text-secondary-foreground border-border",
  },
  video: {
    label: "Video",
    Icon: Film,
    colorClass: "bg-secondary text-secondary-foreground border-border",
  },
};

function getDetailHref(item: ContentItem): string {
  if (item.type === "song" || item.type === "snippet" || item.type === "leak") {
    return item.releaseId ? `/releases/${item.releaseId}` : "/releases";
  }
  if (item.type === "photo") return "/photos";
  return "/latest";
}

function formatViews(n: number): string {
  if (n >= 1000) return `${(n / 1000).toFixed(1)}K views`;
  return `${n} views`;
}

function formatDate(iso: string): string {
  return new Date(iso).toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
  });
}

// ─── Skeleton ────────────────────────────────────────────────────────────────
export function ContentCardSkeleton() {
  return (
    <div className="flex flex-col gap-2">
      <Skeleton className="aspect-video w-full rounded-md" />
      <div className="flex gap-2 px-0.5">
        <Skeleton className="h-8 w-8 rounded-full shrink-0" />
        <div className="flex-1 space-y-2 min-w-0">
          <Skeleton className="h-3.5 w-full" />
          <Skeleton className="h-3 w-2/3" />
        </div>
      </div>
    </div>
  );
}

// ─── Card ────────────────────────────────────────────────────────────────────
interface ContentCardProps {
  item: ContentItem;
}

export function ContentCard({ item }: ContentCardProps) {
  const cfg = TYPE_CONFIG[item.type];
  const href = getDetailHref(item);
  const initials =
    item.member === "deathVailCoven" ? "DV" : item.member.slice(0, 2);

  return (
    <Link
      to={href}
      data-ocid={`content-card-${item.id}`}
      className="group flex flex-col gap-2 cursor-pointer rounded-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
    >
      {/* Thumbnail */}
      <div className="relative aspect-video w-full overflow-hidden rounded-md bg-card border border-border">
        <img
          src={
            item.thumbnailUrl ||
            "/assets/generated/dvc-logo-transparent.dim_280x80.png"
          }
          alt={item.title}
          className="w-full h-full object-cover transition-smooth group-hover:scale-105"
          loading="lazy"
        />

        {/* Duration */}
        {item.duration && (
          <span className="absolute bottom-1.5 right-1.5 text-xs font-mono bg-background/80 text-foreground px-1.5 py-0.5 rounded">
            {item.duration}
          </span>
        )}

        {/* Play overlay */}
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-smooth bg-background/40">
          <div className="rounded-full bg-primary/90 p-3 shadow-lg">
            <Play className="h-5 w-5 fill-primary-foreground text-primary-foreground" />
          </div>
        </div>

        {/* Type badge */}
        <span
          className={`absolute top-1.5 left-1.5 inline-flex items-center gap-1 text-[10px] font-semibold uppercase tracking-wide border rounded px-1.5 py-0.5 ${cfg.colorClass}`}
        >
          <cfg.Icon className="h-2.5 w-2.5" />
          {cfg.label}
        </span>
      </div>

      {/* Meta */}
      <div className="flex gap-2 px-0.5 min-w-0">
        <div className="h-8 w-8 shrink-0 rounded-full bg-muted border border-border flex items-center justify-center text-xs font-bold text-muted-foreground uppercase">
          {initials}
        </div>

        <div className="flex-1 min-w-0">
          <p
            className="text-sm font-semibold leading-snug line-clamp-2 text-foreground group-hover:text-primary transition-colors duration-200"
            title={item.title}
          >
            {item.title}
          </p>
          <p className="text-xs text-muted-foreground mt-0.5 truncate">
            {item.member === "deathVailCoven" ? "deathVail Coven" : item.member}
          </p>
          <p className="text-xs text-muted-foreground truncate">
            {formatViews(item.views)} · {formatDate(item.releaseDate)}
          </p>
        </div>
      </div>
    </Link>
  );
}

// ─── Badge-only export (for reuse) ───────────────────────────────────────────
export function ContentTypeBadge({ type }: { type: ContentType }) {
  const cfg = TYPE_CONFIG[type];
  return (
    <Badge
      className={`inline-flex items-center gap-1 text-[10px] uppercase tracking-wide border ${cfg.colorClass}`}
    >
      <cfg.Icon className="h-2.5 w-2.5" />
      {cfg.label}
    </Badge>
  );
}
