import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Link, useNavigate } from "@tanstack/react-router";
import { LogIn, LogOut, Menu, Search, Shield, User, X } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { useAuth } from "../hooks/use-auth";

interface HeaderProps {
  onMenuToggle: () => void;
  sidebarOpen: boolean;
}

export function Header({ onMenuToggle, sidebarOpen }: HeaderProps) {
  const { isLoggedIn, isLoading, login, logout, principalText } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");
  const [showUserMenu, setShowUserMenu] = useState(false);
  const navigate = useNavigate();
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setShowUserMenu(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  function handleSearch(e: React.FormEvent) {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate({ to: "/search", search: { q: searchQuery.trim() } });
    }
  }

  const shortPrincipal = principalText
    ? `${principalText.slice(0, 5)}...${principalText.slice(-3)}`
    : null;

  return (
    <header
      className="accent-stripe sticky top-0 z-50 flex h-14 items-center gap-3 bg-card border-b border-border px-4 shadow-elevated"
      data-ocid="header"
    >
      {/* Hamburger + Logo */}
      <div className="flex items-center gap-3 shrink-0">
        <button
          type="button"
          onClick={onMenuToggle}
          className="p-1.5 rounded hover:bg-secondary transition-colors"
          aria-label={sidebarOpen ? "Close menu" : "Open menu"}
          data-ocid="nav-hamburger"
        >
          {sidebarOpen ? (
            <X className="w-5 h-5 text-foreground" />
          ) : (
            <Menu className="w-5 h-5 text-foreground" />
          )}
        </button>

        <Link
          to="/"
          className="flex items-center gap-2 group"
          data-ocid="nav-logo"
        >
          <img
            src="/assets/dvc-logo.jpg"
            alt="deathVail Coven"
            className="h-10 w-auto object-contain rounded"
          />
        </Link>
      </div>

      {/* Search */}
      <form
        onSubmit={handleSearch}
        className="flex flex-1 max-w-xl mx-auto items-center gap-2"
        aria-label="Search"
      >
        <div className="relative flex-1">
          <Input
            type="search"
            placeholder="Search songs, members, releases..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-secondary border-border text-foreground placeholder:text-muted-foreground pr-10 h-9"
            aria-label="Search"
            data-ocid="search-input"
          />
        </div>
        <Button
          type="submit"
          size="sm"
          variant="default"
          className="bg-primary text-primary-foreground hover:bg-primary/80 h-9 px-3"
          aria-label="Submit search"
          data-ocid="search-submit"
        >
          <Search className="w-4 h-4" />
        </Button>
      </form>

      {/* User Menu */}
      <div className="relative shrink-0" ref={menuRef}>
        {isLoggedIn ? (
          <button
            type="button"
            onClick={() => setShowUserMenu((v) => !v)}
            className="flex items-center gap-2 px-3 py-1.5 rounded bg-secondary hover:bg-muted border border-border transition-colors text-sm"
            data-ocid="user-menu-trigger"
            aria-label="User menu"
          >
            <User className="w-4 h-4 text-primary" />
            <span className="hidden sm:inline text-foreground font-mono text-xs">
              {shortPrincipal}
            </span>
          </button>
        ) : (
          <Button
            size="sm"
            variant="default"
            onClick={login}
            disabled={isLoading}
            className="bg-primary text-primary-foreground hover:bg-primary/80 h-9"
            data-ocid="login-btn"
          >
            <LogIn className="w-4 h-4 mr-1.5" />
            <span className="hidden sm:inline">Sign In</span>
          </Button>
        )}

        {showUserMenu && isLoggedIn && (
          <div
            className="absolute right-0 top-full mt-2 w-52 bg-popover border border-border rounded shadow-elevated animate-slide-up z-50"
            data-ocid="user-dropdown"
          >
            <div className="px-3 py-2 border-b border-border">
              <p className="text-xs text-muted-foreground font-mono truncate">
                {principalText}
              </p>
            </div>
            <Link
              to="/admin"
              className="flex items-center gap-2 px-3 py-2 text-sm text-foreground hover:bg-secondary transition-colors"
              onClick={() => setShowUserMenu(false)}
              data-ocid="admin-link"
            >
              <Shield className="w-4 h-4 text-primary" />
              Admin Panel
            </Link>
            <button
              type="button"
              onClick={() => {
                logout();
                setShowUserMenu(false);
              }}
              className="flex w-full items-center gap-2 px-3 py-2 text-sm text-foreground hover:bg-secondary transition-colors"
              data-ocid="logout-btn"
            >
              <LogOut className="w-4 h-4 text-muted-foreground" />
              Sign Out
            </button>
          </div>
        )}
      </div>
    </header>
  );
}
