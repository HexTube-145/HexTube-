import { Link, useRouterState } from "@tanstack/react-router";
import {
  Camera,
  ChevronRight,
  Disc3,
  Home,
  Scissors,
  Skull,
  Users,
  Zap,
} from "lucide-react";

interface SidebarProps {
  open: boolean;
  onClose: () => void;
}

const NAV_ITEMS = [
  { label: "Home", path: "/", icon: Home },
  { label: "Latest Stuff", path: "/latest", icon: Zap },
  { label: "New Releases", path: "/releases", icon: Disc3 },
  { label: "Snippets", path: "/snippets", icon: Scissors },
  { label: "Photos", path: "/photos", icon: Camera },
  { label: "Members", path: "/members", icon: Users },
  { label: "deathVail Coven", path: "/coven", icon: Skull },
] as const;

export function Sidebar({ open, onClose }: SidebarProps) {
  const routerState = useRouterState();
  const currentPath = routerState.location.pathname;

  return (
    <>
      {/* Overlay for mobile */}
      {open && (
        <div
          className="fixed inset-0 z-30 bg-background/70 backdrop-blur-sm md:hidden"
          onClick={onClose}
          onKeyDown={(e) => e.key === "Escape" && onClose()}
          role="button"
          tabIndex={0}
          aria-label="Close menu"
        />
      )}

      {/* Sidebar panel */}
      <aside
        className={[
          "fixed md:sticky top-14 left-0 z-40 h-[calc(100vh-3.5rem)] w-56 flex-shrink-0",
          "bg-sidebar border-r border-sidebar-border overflow-y-auto",
          "transition-transform duration-200 ease-in-out",
          open ? "translate-x-0" : "-translate-x-full md:translate-x-0",
          "md:flex md:flex-col",
        ].join(" ")}
        aria-label="Main navigation"
        data-ocid="sidebar"
      >
        <nav className="flex flex-col gap-0.5 p-2 pt-3">
          {NAV_ITEMS.map(({ label, path, icon: Icon }) => {
            const isActive =
              currentPath === path ||
              (path !== "/" && currentPath.startsWith(path));
            return (
              <Link
                key={path}
                to={path}
                onClick={onClose}
                className={[
                  "flex items-center gap-3 px-3 py-2.5 rounded text-sm transition-smooth group",
                  isActive
                    ? "bg-primary/15 text-primary font-medium border-l-2 border-primary"
                    : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground border-l-2 border-transparent",
                ].join(" ")}
                data-ocid={`nav-${label.toLowerCase().replace(/\s+/g, "-")}`}
                aria-current={isActive ? "page" : undefined}
              >
                <Icon
                  className={[
                    "w-4 h-4 shrink-0 transition-colors",
                    label === "deathVail Coven"
                      ? "text-primary"
                      : isActive
                        ? "text-primary"
                        : "text-muted-foreground group-hover:text-sidebar-accent-foreground",
                  ].join(" ")}
                />
                <span className="truncate">{label}</span>
                {label === "deathVail Coven" && (
                  <ChevronRight className="w-3.5 h-3.5 ml-auto text-primary/60 shrink-0" />
                )}
              </Link>
            );
          })}
        </nav>

        {/* Bottom branding */}
        <div className="mt-auto px-4 py-4 border-t border-sidebar-border">
          <p className="text-xs text-muted-foreground leading-relaxed">
            © {new Date().getFullYear()} deathVail Coven.{" "}
            <a
              href={`https://caffeine.ai?utm_source=caffeine-footer&utm_medium=referral&utm_content=${encodeURIComponent(typeof window !== "undefined" ? window.location.hostname : "")}`}
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-primary transition-colors"
            >
              Built with caffeine.ai
            </a>
          </p>
        </div>
      </aside>
    </>
  );
}
