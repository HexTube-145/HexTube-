import { Button } from "@/components/ui/button";
import { Calendar, Clock, Music, Pause, Play, X } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import type { Track } from "../types";

interface SongModalProps {
  track: Track | null;
  releaseTitle: string;
  onClose: () => void;
}

function formatDate(dateStr: string): string {
  return new Date(dateStr).toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });
}

export function SongModal({ track, releaseTitle, onClose }: SongModalProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // Reset playback when track changes
  // biome-ignore lint/correctness/useExhaustiveDependencies: reset on track identity change
  useEffect(() => {
    setIsPlaying(false);
    const audio = audioRef.current;
    if (audio) {
      audio.pause();
      audio.currentTime = 0;
    }
  }, [track?.id]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      audioRef.current?.pause();
    };
  }, []);

  // Keyboard close
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [onClose]);

  // Prevent body scroll while open
  useEffect(() => {
    if (track) {
      document.body.style.overflow = "hidden";
    }
    return () => {
      document.body.style.overflow = "";
    };
  }, [track]);

  if (!track) return null;

  const handlePlayPause = () => {
    if (!track.audioUrl) return;

    if (!audioRef.current) {
      audioRef.current = new Audio(track.audioUrl);
      audioRef.current.onended = () => setIsPlaying(false);
    }

    if (isPlaying) {
      audioRef.current.pause();
      setIsPlaying(false);
    } else {
      audioRef.current
        .play()
        .then(() => setIsPlaying(true))
        .catch(() => setIsPlaying(false));
    }
  };

  return (
    <dialog
      open
      className="fixed inset-0 z-50 w-full h-full m-0 max-w-full max-h-full bg-transparent p-0 flex items-end sm:items-center justify-center"
      aria-label={`Song details: ${track.title}`}
      data-ocid="song-modal-backdrop"
    >
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/70 backdrop-blur-sm"
        onClick={onClose}
        onKeyDown={(e) => e.key === "Enter" && onClose()}
        role="button"
        tabIndex={-1}
        aria-label="Close modal"
      />

      {/* Panel — slides up on mobile, centers on desktop */}
      <div
        className="relative w-full sm:w-[480px] sm:max-w-[90vw] bg-card border border-border rounded-t-2xl sm:rounded-2xl shadow-2xl p-6 sm:p-8 animate-in slide-in-from-bottom-8 sm:zoom-in-95 duration-300"
        onClick={(e) => e.stopPropagation()}
        onKeyDown={(e) => e.stopPropagation()}
        role="document"
      >
        {/* Drag indicator (mobile) */}
        <div className="absolute top-3 left-1/2 -translate-x-1/2 w-10 h-1 rounded-full bg-border sm:hidden" />

        {/* Close */}
        <Button
          type="button"
          variant="ghost"
          size="icon"
          className="absolute top-4 right-4 text-muted-foreground hover:text-foreground transition-colors"
          onClick={onClose}
          aria-label="Close song modal"
          data-ocid="song-modal-close"
        >
          <X className="h-5 w-5" />
        </Button>

        {/* From release */}
        <p className="text-xs text-muted-foreground font-body uppercase tracking-widest mb-2">
          Track {track.trackNumber} · {releaseTitle}
        </p>

        {/* Title */}
        <h2 className="font-display text-2xl sm:text-3xl font-bold text-foreground leading-tight mb-6">
          {track.title}
        </h2>

        {/* Meta grid */}
        <div className="grid grid-cols-2 gap-4 mb-8">
          <div className="flex items-center gap-2 bg-muted/40 rounded-lg px-4 py-3">
            <Calendar className="h-4 w-4 text-primary shrink-0" />
            <div className="min-w-0">
              <p className="text-xs text-muted-foreground">Released</p>
              <p className="text-sm font-medium text-foreground truncate">
                {formatDate(track.releaseDate)}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 bg-muted/40 rounded-lg px-4 py-3">
            <Clock className="h-4 w-4 text-primary shrink-0" />
            <div>
              <p className="text-xs text-muted-foreground">Duration</p>
              <p className="text-sm font-medium text-foreground">
                {track.duration}
              </p>
            </div>
          </div>
        </div>

        {/* Play / Pause button */}
        <button
          type="button"
          className={[
            "w-full flex items-center justify-center gap-3 rounded-xl py-4 px-6",
            "font-body font-semibold text-base transition-smooth",
            track.audioUrl
              ? "bg-primary text-primary-foreground hover:opacity-90 active:scale-[0.98] cursor-pointer"
              : "bg-muted text-muted-foreground cursor-not-allowed opacity-60",
          ].join(" ")}
          onClick={handlePlayPause}
          onKeyDown={(e) => e.key === "Enter" && handlePlayPause()}
          disabled={!track.audioUrl}
          data-ocid="song-modal-play-btn"
          aria-label={isPlaying ? "Pause preview" : "Play preview"}
        >
          {isPlaying ? (
            <>
              <Pause className="h-5 w-5 fill-current" />
              Pause Preview
            </>
          ) : (
            <>
              {track.audioUrl ? (
                <Play className="h-5 w-5 fill-current" />
              ) : (
                <Music className="h-5 w-5" />
              )}
              {track.audioUrl ? "Play Preview" : "No Preview Available"}
            </>
          )}
        </button>
      </div>
    </dialog>
  );
}
