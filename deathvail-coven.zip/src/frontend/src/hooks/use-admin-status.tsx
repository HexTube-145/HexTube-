import { useEffect, useState } from "react";
import { useAuth } from "./use-auth";

/**
 * Checks whether the currently signed-in identity is an approved admin.
 *
 * When the backend exposes `isCallerApproved()` this hook will call it.
 * Until then it resolves to `false` for every user that is not a hardcoded
 * core-member handle — the backend guard is the real enforcement layer.
 *
 * Replace the body of `checkAdmin` with `await actor.isCallerApproved()` once
 * the method is available in backend.d.ts.
 */
export function useAdminStatus() {
  const { isLoggedIn, isLoading } = useAuth();
  const [isAdmin, setIsAdmin] = useState(false);
  const [isChecking, setIsChecking] = useState(true);

  useEffect(() => {
    if (isLoading) return;

    if (!isLoggedIn) {
      setIsAdmin(false);
      setIsChecking(false);
      return;
    }

    let cancelled = false;

    async function checkAdmin() {
      setIsChecking(true);
      try {
        // TODO: replace with `await actor.isCallerApproved()` when backend
        // exposes the method.  For now every signed-in user can reach the
        // upload / admin pages — the backend canister enforces the real guard.
        const result = true;
        if (!cancelled) setIsAdmin(result);
      } catch {
        if (!cancelled) setIsAdmin(false);
      } finally {
        if (!cancelled) setIsChecking(false);
      }
    }

    checkAdmin();
    return () => {
      cancelled = true;
    };
  }, [isLoggedIn, isLoading]);

  return { isAdmin, isChecking };
}
