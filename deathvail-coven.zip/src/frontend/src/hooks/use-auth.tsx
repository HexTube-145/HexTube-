import { useInternetIdentity } from "@caffeineai/core-infrastructure";
import { useCallback } from "react";

export function useAuth() {
  const { login, clear, loginStatus, identity } = useInternetIdentity();

  const isLoggedIn = loginStatus === "success" && identity != null;
  const isLoading = loginStatus === "logging-in";

  const handleLogin = useCallback(async () => {
    await login();
  }, [login]);

  const handleLogout = useCallback(() => {
    clear();
  }, [clear]);

  const principalText = identity?.getPrincipal()?.toText() ?? null;

  return {
    isLoggedIn,
    isLoading,
    identity,
    principalText,
    login: handleLogin,
    logout: handleLogout,
    loginStatus,
  };
}
