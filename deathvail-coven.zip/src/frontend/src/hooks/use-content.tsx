import { useCallback, useState } from "react";
import type { ContentItem, ContentType, MemberHandle } from "../types";

// Sample content — realistic deathVail Coven data
const SAMPLE_CONTENT: ContentItem[] = [
  {
    id: "c1",
    title: "Veil of Ashes",
    type: "song",
    member: "deathVailCoven",
    description: "Full track from the upcoming album. Dark, heavy, relentless.",
    mediaUrl: "",
    thumbnailUrl: "/assets/generated/dvc-logo-transparent.dim_280x80.png",
    releaseDate: "2026-03-15",
    duration: "4:12",
    views: 3842,
    releaseId: "r1",
  },
  {
    id: "c2",
    title: "Otrik - Throne of Static (Snippet)",
    type: "snippet",
    member: "Otrik",
    description: "30-second preview of the new single. Bass-heavy production.",
    mediaUrl: "",
    thumbnailUrl: "/assets/generated/dvc-logo-transparent.dim_280x80.png",
    releaseDate: "2026-03-28",
    duration: "0:30",
    views: 1204,
    releaseId: "r2",
  },
  {
    id: "c3",
    title: "BWTCHR - Crimson Drift",
    type: "song",
    member: "BWTCHR",
    description:
      "Atmospheric beat with distorted vocals and industrial percussion.",
    mediaUrl: "",
    thumbnailUrl: "/assets/generated/dvc-logo-transparent.dim_280x80.png",
    releaseDate: "2026-02-10",
    duration: "3:47",
    views: 2190,
    releaseId: "r3",
  },
  {
    id: "c4",
    title: "CHUCKII - Late Night Sessions Photo Dump",
    type: "photo",
    member: "CHUCKII",
    description: "Behind the scenes from the studio, 3am grind.",
    mediaUrl: "",
    thumbnailUrl: "/assets/generated/dvc-logo-transparent.dim_280x80.png",
    releaseDate: "2026-04-01",
    duration: undefined,
    views: 890,
  },
  {
    id: "c5",
    title: "Nolon - Hollow Frequency (Leak)",
    type: "leak",
    member: "Nolon",
    description: "Early mix leaked before mastering — raw and unfiltered.",
    mediaUrl: "",
    thumbnailUrl: "/assets/generated/dvc-logo-transparent.dim_280x80.png",
    releaseDate: "2026-04-05",
    duration: "5:03",
    views: 4401,
    releaseId: "r4",
  },
  {
    id: "c6",
    title: "deathVail Coven - Live Rehearsal Footage",
    type: "video",
    member: "deathVailCoven",
    description: "Full rehearsal session, uncut. Watch the Coven work.",
    mediaUrl: "",
    thumbnailUrl: "/assets/generated/dvc-logo-transparent.dim_280x80.png",
    releaseDate: "2026-04-08",
    duration: "18:32",
    views: 7620,
  },
  {
    id: "c7",
    title: "Otrik - Shadow Protocol",
    type: "song",
    member: "Otrik",
    description:
      "Solo track showcasing Otrik's signature layered sound design.",
    mediaUrl: "",
    thumbnailUrl: "/assets/generated/dvc-logo-transparent.dim_280x80.png",
    releaseDate: "2026-01-20",
    duration: "3:58",
    views: 1876,
    releaseId: "r2",
  },
  {
    id: "c8",
    title: "CHUCKII x BWTCHR - Collab Session",
    type: "video",
    member: "CHUCKII",
    description: "Behind the boards collab session. Two producers, one track.",
    mediaUrl: "",
    thumbnailUrl: "/assets/generated/dvc-logo-transparent.dim_280x80.png",
    releaseDate: "2026-03-02",
    duration: "12:14",
    views: 3310,
  },
];

export function useContent() {
  const [content] = useState<ContentItem[]>(SAMPLE_CONTENT);

  const getByType = useCallback(
    (type: ContentType) => content.filter((c) => c.type === type),
    [content],
  );

  const getByMember = useCallback(
    (member: MemberHandle) => content.filter((c) => c.member === member),
    [content],
  );

  const getById = useCallback(
    (id: string) => content.find((c) => c.id === id) ?? null,
    [content],
  );

  const getLatest = useCallback(
    (limit = 8) =>
      [...content]
        .sort(
          (a, b) =>
            new Date(b.releaseDate).getTime() -
            new Date(a.releaseDate).getTime(),
        )
        .slice(0, limit),
    [content],
  );

  const search = useCallback(
    (query: string) => {
      const q = query.toLowerCase();
      return content.filter(
        (c) =>
          c.title.toLowerCase().includes(q) ||
          c.description.toLowerCase().includes(q) ||
          c.member.toLowerCase().includes(q),
      );
    },
    [content],
  );

  return { content, getByType, getByMember, getById, getLatest, search };
}
