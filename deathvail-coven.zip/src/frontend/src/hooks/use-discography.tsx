import { useCallback, useState } from "react";
import type { Release, ReleaseType, Track } from "../types";

const SAMPLE_TRACKS: Track[] = [
  {
    id: "t1",
    title: "Veil of Ashes",
    duration: "4:12",
    releaseDate: "2026-03-15",
    trackNumber: 1,
    releaseId: "r1",
  },
  {
    id: "t2",
    title: "Hollow Remnants",
    duration: "3:44",
    releaseDate: "2026-03-15",
    trackNumber: 2,
    releaseId: "r1",
  },
  {
    id: "t3",
    title: "Black Cathedral",
    duration: "5:01",
    releaseDate: "2026-03-15",
    trackNumber: 3,
    releaseId: "r1",
  },
  {
    id: "t4",
    title: "Crimson Vow",
    duration: "4:38",
    releaseDate: "2026-03-15",
    trackNumber: 4,
    releaseId: "r1",
  },
  {
    id: "t5",
    title: "The Descent",
    duration: "6:22",
    releaseDate: "2026-03-15",
    trackNumber: 5,
    releaseId: "r1",
  },
  {
    id: "t6",
    title: "Ashen Ground",
    duration: "3:58",
    releaseDate: "2026-03-15",
    trackNumber: 6,
    releaseId: "r1",
  },
  {
    id: "t7",
    title: "Throne of Static",
    duration: "3:55",
    releaseDate: "2026-03-28",
    trackNumber: 1,
    releaseId: "r2",
  },
  {
    id: "t8",
    title: "Shadow Protocol",
    duration: "3:58",
    releaseDate: "2026-01-20",
    trackNumber: 2,
    releaseId: "r2",
  },
  {
    id: "t9",
    title: "Ghost Meridian",
    duration: "4:10",
    releaseDate: "2026-03-28",
    trackNumber: 3,
    releaseId: "r2",
  },
  {
    id: "t10",
    title: "Crimson Drift",
    duration: "3:47",
    releaseDate: "2026-02-10",
    trackNumber: 1,
    releaseId: "r3",
  },
  {
    id: "t11",
    title: "Hollow Frequency",
    duration: "5:03",
    releaseDate: "2026-04-05",
    trackNumber: 1,
    releaseId: "r4",
  },
];

const SAMPLE_RELEASES: Release[] = [
  {
    id: "r1",
    title: "Beneath the Veil",
    type: "album",
    member: "deathVailCoven",
    coverUrl: "/assets/generated/dvc-logo-transparent.dim_280x80.png",
    releaseDate: "2026-03-15",
    description:
      "The debut full-length album from deathVail Coven. Six tracks of industrial darkness and raw emotion.",
    tracklist: SAMPLE_TRACKS.filter((t) => t.releaseId === "r1"),
  },
  {
    id: "r2",
    title: "Fracture EP",
    type: "ep",
    member: "Otrik",
    coverUrl: "/assets/generated/dvc-logo-transparent.dim_280x80.png",
    releaseDate: "2026-03-28",
    description:
      "Three-track EP from Otrik. Dense layered sound design meets heavy percussion.",
    tracklist: SAMPLE_TRACKS.filter((t) => t.releaseId === "r2"),
  },
  {
    id: "r3",
    title: "Crimson Drift",
    type: "single",
    member: "BWTCHR",
    coverUrl: "/assets/generated/dvc-logo-transparent.dim_280x80.png",
    releaseDate: "2026-02-10",
    description:
      "BWTCHR's standout single blending atmospheric beats with distorted vocals.",
    tracklist: SAMPLE_TRACKS.filter((t) => t.releaseId === "r3"),
  },
  {
    id: "r4",
    title: "Hollow Frequency",
    type: "single",
    member: "Nolon",
    coverUrl: "/assets/generated/dvc-logo-transparent.dim_280x80.png",
    releaseDate: "2026-04-05",
    description:
      "Nolon's raw and unfiltered debut single — five minutes of pure atmosphere.",
    tracklist: SAMPLE_TRACKS.filter((t) => t.releaseId === "r4"),
  },
];

export function useDiscography() {
  const [releases] = useState<Release[]>(SAMPLE_RELEASES);

  const getById = useCallback(
    (id: string) => releases.find((r) => r.id === id) ?? null,
    [releases],
  );

  const getByType = useCallback(
    (type: ReleaseType) => releases.filter((r) => r.type === type),
    [releases],
  );

  const getLatest = useCallback(
    (limit = 4) =>
      [...releases]
        .sort(
          (a, b) =>
            new Date(b.releaseDate).getTime() -
            new Date(a.releaseDate).getTime(),
        )
        .slice(0, limit),
    [releases],
  );

  return { releases, getById, getByType, getLatest };
}
