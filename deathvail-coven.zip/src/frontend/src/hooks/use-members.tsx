import { useCallback, useState } from "react";
import type { Member, MemberHandle } from "../types";

const SAMPLE_MEMBERS: Member[] = [
  {
    handle: "Otrik",
    displayName: "Otrik",
    bio: "Producer and beatmaker. Specializes in layered sound design, heavy textures, and industrial percussion. The sonic architect of deathVail Coven.",
    avatarUrl: "/assets/generated/dvc-logo-transparent.dim_280x80.png",
    role: "Producer / Sound Design",
    joinedDate: "2024-01-01",
  },
  {
    handle: "BWTCHR",
    displayName: "BWTCHR",
    bio: "Bewitcher. Vocalist and producer. Atmospheric beats, distorted soundscapes, and haunting vocal textures define his contributions to the Coven.",
    avatarUrl: "/assets/generated/dvc-logo-transparent.dim_280x80.png",
    role: "Vocalist / Producer",
    joinedDate: "2024-01-01",
  },
  {
    handle: "CHUCKII",
    displayName: "CHUCKII",
    bio: "Multi-instrumentalist and video director. Documents the Coven's creative process through raw footage and behind-the-scenes content.",
    avatarUrl: "/assets/generated/dvc-logo-transparent.dim_280x80.png",
    role: "Multi-Instrumentalist / Video",
    joinedDate: "2024-01-01",
  },
  {
    handle: "Nolon",
    displayName: "Nolon",
    bio: "The newest force in the Coven. Brings a raw, unfiltered approach to songwriting and production that keeps the collective pushing boundaries.",
    avatarUrl: "/assets/generated/dvc-logo-transparent.dim_280x80.png",
    role: "Songwriter / Producer",
    joinedDate: "2024-06-01",
  },
];

export function useMembers() {
  const [members] = useState<Member[]>(SAMPLE_MEMBERS);

  const getByHandle = useCallback(
    (handle: MemberHandle) => members.find((m) => m.handle === handle) ?? null,
    [members],
  );

  return { members, getByHandle };
}
