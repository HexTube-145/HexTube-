import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "@tanstack/react-router";
import {
  CheckCircle,
  Clock,
  Lock,
  Shield,
  Upload,
  Users,
  XCircle,
} from "lucide-react";
import { useState } from "react";
import { useAdminStatus } from "../hooks/use-admin-status";
import { useAuth } from "../hooks/use-auth";
import type { ApprovalRequest } from "../types";

// Mock approval requests — will be replaced by real backend calls via setApproval / listApprovals
const INITIAL_REQUESTS: ApprovalRequest[] = [
  {
    principal: "qoctq-giaaa-aaaaa-aaaea-cai",
    handle: "GhostWriter99",
    requestedAt: "2026-04-10",
    status: "pending",
  },
  {
    principal: "rrkah-fqaaa-aaaaa-aaaaq-cai",
    handle: "NightOwlBeats",
    requestedAt: "2026-04-09",
    status: "pending",
  },
  {
    principal: "ryjl3-tyaaa-aaaaa-aaaba-cai",
    handle: "ShadowVox",
    requestedAt: "2026-04-07",
    status: "approved",
  },
  {
    principal: "r7inp-6aaaa-aaaaa-aaabq-cai",
    handle: "VoidCreator",
    requestedAt: "2026-04-05",
    status: "rejected",
  },
];

const COVEN_ADMINS = [
  { handle: "Otrik", principal: "Otrik (core member)" },
  { handle: "BWTCHR", principal: "BWTCHR (core member)" },
  { handle: "CHUCKII", principal: "CHUCKII (core member)" },
  { handle: "Nolon", principal: "Nolon (core member)" },
];

const STATUS_CONFIG = {
  pending: {
    icon: Clock,
    label: "Pending",
    className: "bg-yellow-900/30 text-yellow-400 border-yellow-800/40",
  },
  approved: {
    icon: CheckCircle,
    label: "Approved",
    className: "bg-primary/20 text-primary border-primary/30",
  },
  rejected: {
    icon: XCircle,
    label: "Rejected",
    className: "bg-destructive/20 text-destructive border-destructive/30",
  },
};

function AccessDenied({
  reason,
}: {
  reason: "not-logged-in" | "not-admin";
}) {
  return (
    <div
      className="flex flex-col items-center justify-center py-24 gap-4"
      data-ocid="admin-locked"
    >
      <Lock className="w-12 h-12 text-muted-foreground opacity-40" />
      <h2 className="text-xl font-display font-bold text-foreground">
        {reason === "not-logged-in" ? "Sign In Required" : "Admin Access Only"}
      </h2>
      <p className="text-muted-foreground text-sm text-center max-w-xs">
        {reason === "not-logged-in"
          ? "You must be signed in to access this panel."
          : "Only approved admins can access this panel. No one gets admin access automatically on sign-up — an existing admin must approve you."}
      </p>
      <Link
        to="/"
        className="px-4 py-2 bg-primary text-primary-foreground rounded text-sm hover:bg-primary/80 transition-smooth"
      >
        ← Back to Home
      </Link>
    </div>
  );
}

export function AdminPage() {
  const { isLoggedIn, principalText } = useAuth();
  const { isAdmin, isChecking } = useAdminStatus();
  const [requests, setRequests] = useState<ApprovalRequest[]>(INITIAL_REQUESTS);

  const handleApprove = (principal: string) => {
    // In production: actor.setApproval(principal, { #approved })
    setRequests((prev) =>
      prev.map((r) =>
        r.principal === principal ? { ...r, status: "approved" } : r,
      ),
    );
  };

  const handleReject = (principal: string) => {
    // In production: actor.setApproval(principal, { #rejected })
    setRequests((prev) =>
      prev.map((r) =>
        r.principal === principal ? { ...r, status: "rejected" } : r,
      ),
    );
  };

  if (isChecking) {
    return (
      <div className="px-6 py-8 max-w-3xl space-y-4">
        <Skeleton className="h-8 w-48" />
        <Skeleton className="h-4 w-72" />
        <Skeleton className="h-16 w-full" />
        <Skeleton className="h-16 w-full" />
      </div>
    );
  }

  if (!isLoggedIn) return <AccessDenied reason="not-logged-in" />;
  if (!isAdmin) return <AccessDenied reason="not-admin" />;

  const pending = requests.filter((r) => r.status === "pending");
  const processed = requests.filter((r) => r.status !== "pending");

  return (
    <div className="px-6 py-8 max-w-3xl">
      {/* Header */}
      <div className="flex items-start justify-between mb-6">
        <div>
          <h1 className="text-2xl font-display font-bold text-foreground flex items-center gap-2 mb-1">
            <Shield className="w-6 h-6 text-primary" />
            Admin Panel
          </h1>
          <p className="text-muted-foreground text-sm">
            Manage member approvals and site access. Promotion is manual — no
            one becomes an admin automatically.
          </p>
        </div>
        <Link to="/upload">
          <Button
            type="button"
            variant="default"
            size="sm"
            className="flex items-center gap-2 bg-primary text-primary-foreground hover:bg-primary/80"
            data-ocid="admin-upload-link"
          >
            <Upload className="w-4 h-4" />
            Upload Content
          </Button>
        </Link>
      </div>

      {/* Current session principal */}
      <div className="bg-card border border-border rounded p-4 mb-8 accent-stripe">
        <p className="text-xs text-muted-foreground mb-1">Signed in as</p>
        <p className="text-sm font-mono text-foreground break-all">
          {principalText}
        </p>
      </div>

      {/* Core Coven Admins */}
      <section className="mb-8">
        <h2 className="text-base font-display font-bold text-foreground flex items-center gap-2 mb-4">
          <Users className="w-4 h-4 text-primary" />
          Approved Admins
        </h2>
        <div className="flex flex-col gap-2">
          {COVEN_ADMINS.map((admin) => (
            <div
              key={admin.handle}
              className="flex items-center justify-between p-3 bg-card border border-border rounded"
              data-ocid={`admin-member-${admin.handle}`}
            >
              <div className="flex flex-col gap-0.5">
                <span className="text-sm font-medium text-foreground">
                  {admin.handle}
                </span>
                <span className="text-xs text-muted-foreground">
                  {admin.principal}
                </span>
              </div>
              <Badge className="bg-primary/20 text-primary border-primary/30 text-xs">
                <CheckCircle className="w-3 h-3 mr-1" />
                Admin
              </Badge>
            </div>
          ))}
        </div>
        <p className="text-xs text-muted-foreground mt-3 leading-relaxed">
          These are the deathVail Coven core members with admin access. To
          promote additional users, approve their request below.
        </p>
      </section>

      <Separator className="bg-border mb-8" />

      {/* Pending Requests */}
      <section className="mb-8">
        <h2 className="text-base font-display font-bold text-foreground flex items-center gap-2 mb-4">
          <Clock className="w-4 h-4 text-primary" />
          Pending Requests
          {pending.length > 0 && (
            <span className="ml-1 px-1.5 py-0.5 text-xs bg-yellow-900/40 text-yellow-400 rounded-full">
              {pending.length}
            </span>
          )}
        </h2>

        {pending.length === 0 ? (
          <div
            className="text-center py-8 text-muted-foreground text-sm border border-dashed border-border rounded"
            data-ocid="pending-empty"
          >
            No pending requests right now.
          </div>
        ) : (
          <div className="flex flex-col gap-2">
            {pending.map((req) => (
              <div
                key={req.principal}
                className="flex items-center justify-between p-3 bg-card border border-border rounded gap-3"
                data-ocid={`approval-row-${req.handle}`}
              >
                <div className="flex flex-col gap-0.5 min-w-0">
                  <span className="text-sm font-medium text-foreground">
                    {req.handle}
                  </span>
                  <span className="text-xs text-muted-foreground font-mono truncate">
                    {req.principal}
                  </span>
                  <span className="text-xs text-muted-foreground">
                    Requested {new Date(req.requestedAt).toLocaleDateString()}
                  </span>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <Button
                    type="button"
                    size="sm"
                    variant="default"
                    onClick={() => handleApprove(req.principal)}
                    className="bg-primary/80 text-primary-foreground h-7 px-3 text-xs hover:bg-primary"
                    data-ocid={`approve-btn-${req.handle}`}
                  >
                    <CheckCircle className="w-3 h-3 mr-1" />
                    Approve
                  </Button>
                  <Button
                    type="button"
                    size="sm"
                    variant="ghost"
                    onClick={() => handleReject(req.principal)}
                    className="text-destructive h-7 px-2 text-xs hover:bg-destructive/10"
                    data-ocid={`reject-btn-${req.handle}`}
                  >
                    <XCircle className="w-3 h-3 mr-1" />
                    Reject
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* Processed Requests */}
      {processed.length > 0 && (
        <section>
          <h2 className="text-base font-display font-bold text-foreground flex items-center gap-2 mb-4">
            <CheckCircle className="w-4 h-4 text-muted-foreground" />
            Processed Requests
          </h2>
          <div className="flex flex-col gap-2">
            {processed.map((req) => {
              const cfg = STATUS_CONFIG[req.status];
              const Icon = cfg.icon;
              return (
                <div
                  key={req.principal}
                  className="flex items-center justify-between p-3 bg-card border border-border rounded gap-3 opacity-70"
                  data-ocid={`processed-row-${req.handle}`}
                >
                  <div className="flex flex-col gap-0.5 min-w-0">
                    <span className="text-sm font-medium text-foreground">
                      {req.handle}
                    </span>
                    <span className="text-xs text-muted-foreground">
                      {new Date(req.requestedAt).toLocaleDateString()}
                    </span>
                  </div>
                  <span
                    className={`flex items-center gap-1 text-xs px-2 py-0.5 rounded border font-medium ${cfg.className}`}
                  >
                    <Icon className="w-3 h-3" />
                    {cfg.label}
                  </span>
                </div>
              );
            })}
          </div>
        </section>
      )}
    </div>
  );
}
