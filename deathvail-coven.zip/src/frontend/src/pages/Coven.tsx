import { Badge } from "@/components/ui/badge";
import { Link } from "@tanstack/react-router";
import { motion } from "motion/react";
import { useState } from "react";
import { useContent } from "../hooks/use-content";
import { useMembers } from "../hooks/use-members";
import type { ContentItem, ContentType } from "../types";

// ── Filter config ──────────────────────────────────────────────────────────────

type FilterTab = "all" | ContentType;

const FILTER_TABS: { id: FilterTab; label: string }[] = [
  { id: "all", label: "All" },
  { id: "song", label: "Songs" },
  { id: "snippet", label: "Snippets" },
  { id: "photo", label: "Photos" },
  { id: "video", label: "Videos" },
  { id: "leak", label: "Leaks" },
];

const TYPE_BADGE: Record<ContentType, string> = {
  song: "bg-primary/20 text-primary border-primary/30",
  snippet: "bg-accent/20 text-accent border-accent/30",
  leak: "bg-destructive/20 text-destructive border-destructive/30",
  photo: "bg-secondary text-secondary-foreground border-border",
  video: "bg-blue-900/30 text-blue-300 border-blue-800/40",
};

const MEMBER_INITIALS: Record<string, string> = {
  Otrik: "OT",
  BWTCHR: "BW",
  CHUCKII: "CK",
  Nolon: "NL",
};

// ── Content Card ───────────────────────────────────────────────────────────────

function ContentCard({ item, index }: { item: ContentItem; index: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay: index * 0.05 }}
      className="group bg-card border border-border rounded hover:border-primary/50 transition-smooth overflow-hidden cursor-pointer"
      data-ocid={`coven-content-${item.id}`}
    >
      {/* Thumbnail */}
      <div className="relative aspect-video bg-muted overflow-hidden">
        <img
          src={item.thumbnailUrl}
          alt={item.title}
          className="w-full h-full object-contain p-4 opacity-50 group-hover:opacity-75 transition-smooth"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-background/80 to-transparent" />
        {item.duration && (
          <span className="absolute bottom-1.5 right-2 text-[10px] font-mono bg-background/80 px-1.5 py-0.5 rounded">
            {item.duration}
          </span>
        )}
        <span
          className={`absolute top-2 left-2 text-[10px] px-2 py-0.5 rounded border font-medium uppercase tracking-wide ${TYPE_BADGE[item.type]}`}
        >
          {item.type}
        </span>
      </div>

      {/* Meta */}
      <div className="p-3 space-y-1">
        <h3 className="text-sm font-medium text-foreground line-clamp-2 leading-snug">
          {item.title}
        </h3>
        <div className="flex items-center gap-1.5 flex-wrap">
          <span className="text-[11px] text-primary font-medium">
            {item.member === "deathVailCoven" ? "deathVail Coven" : item.member}
          </span>
          <span className="text-muted-foreground text-[11px]">·</span>
          <span className="text-[11px] text-muted-foreground">
            {item.views.toLocaleString()} views
          </span>
          <span className="text-muted-foreground text-[11px]">·</span>
          <span className="text-[11px] text-muted-foreground">
            {new Date(item.releaseDate).toLocaleDateString()}
          </span>
        </div>
      </div>
    </motion.div>
  );
}

// ── Member Chip ────────────────────────────────────────────────────────────────

function MemberChip({
  handle,
  displayName,
}: { handle: string; displayName: string }) {
  return (
    <Link
      to="/members/$handle"
      params={{ handle }}
      className="flex items-center gap-2.5 px-4 py-2.5 bg-card border border-border rounded-full hover:border-primary/60 hover:bg-primary/5 transition-smooth group"
      data-ocid={`coven-member-chip-${handle}`}
    >
      <div className="w-8 h-8 rounded-full bg-primary/15 border border-primary/30 flex items-center justify-center shrink-0">
        <span className="text-[10px] font-bold text-primary font-mono">
          {MEMBER_INITIALS[handle] ?? handle.slice(0, 2).toUpperCase()}
        </span>
      </div>
      <span className="text-sm font-medium text-foreground group-hover:text-primary transition-smooth">
        {displayName}
      </span>
    </Link>
  );
}

// ── Main Page ──────────────────────────────────────────────────────────────────

export function CovenPage() {
  const { content } = useContent();
  const { members } = useMembers();
  const [activeFilter, setActiveFilter] = useState<FilterTab>("all");

  // All content sorted by newest first
  const sortedContent = [...content].sort(
    (a, b) =>
      new Date(b.releaseDate).getTime() - new Date(a.releaseDate).getTime(),
  );

  const filteredContent =
    activeFilter === "all"
      ? sortedContent
      : sortedContent.filter((c) => c.type === activeFilter);

  const totalViews = content.reduce((acc, c) => acc + c.views, 0);

  return (
    <div className="flex flex-col min-h-screen">
      {/* ── Hero Banner ─────────────────────────────────────────────────────── */}
      <section className="relative bg-card border-b border-border overflow-hidden">
        {/* Decorative gradient */}
        <div className="absolute inset-0 bg-gradient-to-br from-primary/20 via-transparent to-accent/10 pointer-events-none" />
        <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary/60 to-transparent" />

        <div className="relative px-6 pt-10 pb-8">
          {/* Eyebrow */}
          <motion.div
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
            className="flex items-center gap-2 mb-5"
          >
            <div className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
            <span className="text-xs uppercase tracking-[0.25em] text-primary font-medium">
              The Collective
            </span>
          </motion.div>

          {/* Title */}
          <motion.h1
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.45, delay: 0.05 }}
            className="text-4xl md:text-6xl font-display font-bold text-foreground mb-3 leading-tight"
          >
            deathVail <span className="text-primary">Coven</span>
          </motion.h1>

          {/* Subtitle */}
          <motion.p
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.1 }}
            className="text-muted-foreground max-w-lg leading-relaxed mb-6"
          >
            All content from the entire team — songs, snippets, leaks, photos,
            and videos from Otrik, BWTCHR, CHUCKII, and Nolon.
          </motion.p>

          {/* Stats */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.4, delay: 0.15 }}
            className="flex items-center gap-5 mb-7"
          >
            <div className="flex flex-col">
              <span className="text-lg font-display font-bold text-foreground">
                {content.length}
              </span>
              <span className="text-[11px] text-muted-foreground uppercase tracking-wide">
                Posts
              </span>
            </div>
            <div className="w-px h-8 bg-border" />
            <div className="flex flex-col">
              <span className="text-lg font-display font-bold text-foreground">
                {totalViews.toLocaleString()}
              </span>
              <span className="text-[11px] text-muted-foreground uppercase tracking-wide">
                Total Views
              </span>
            </div>
            <div className="w-px h-8 bg-border" />
            <div className="flex flex-col">
              <span className="text-lg font-display font-bold text-foreground">
                4
              </span>
              <span className="text-[11px] text-muted-foreground uppercase tracking-wide">
                Members
              </span>
            </div>
          </motion.div>

          {/* Member chips */}
          <motion.div
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.2 }}
            className="flex flex-wrap gap-2"
          >
            {members.map((member) => (
              <MemberChip
                key={member.handle}
                handle={member.handle}
                displayName={member.displayName}
              />
            ))}
          </motion.div>
        </div>
      </section>

      {/* ── Filter Tabs ─────────────────────────────────────────────────────── */}
      <section className="bg-card border-b border-border sticky top-14 z-10">
        <div className="px-6 flex items-center gap-1 overflow-x-auto scrollbar-none py-1">
          {FILTER_TABS.map((tab) => {
            const isActive = activeFilter === tab.id;
            const count =
              tab.id === "all"
                ? content.length
                : content.filter((c) => c.type === tab.id).length;
            if (count === 0 && tab.id !== "all") return null;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveFilter(tab.id)}
                data-ocid={`coven-filter-${tab.id}`}
                className={`flex items-center gap-1.5 px-4 py-2.5 text-sm font-medium rounded transition-smooth whitespace-nowrap ${
                  isActive
                    ? "text-primary border-b-2 border-primary"
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                {tab.label}
                <Badge
                  variant="secondary"
                  className="text-[10px] px-1.5 py-0 min-w-[1.25rem] h-4 flex items-center justify-center"
                >
                  {count}
                </Badge>
              </button>
            );
          })}
        </div>
      </section>

      {/* ── Content Grid ────────────────────────────────────────────────────── */}
      <section className="flex-1 px-6 py-6 bg-background">
        {filteredContent.length === 0 ? (
          <div
            className="flex flex-col items-center justify-center py-24 text-center"
            data-ocid="coven-empty-state"
          >
            <div className="w-14 h-14 rounded-full bg-muted flex items-center justify-center mb-4">
              <span className="text-2xl">🎵</span>
            </div>
            <h3 className="text-foreground font-medium mb-2">No content yet</h3>
            <p className="text-muted-foreground text-sm max-w-xs">
              No {activeFilter !== "all" ? `${activeFilter}s` : "content"}{" "}
              posted yet. Check back soon.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {filteredContent.map((item, i) => (
              <ContentCard key={item.id} item={item} index={i} />
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
