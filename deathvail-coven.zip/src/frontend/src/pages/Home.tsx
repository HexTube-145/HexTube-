import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Link } from "@tanstack/react-router";
import { useNavigate } from "@tanstack/react-router";
import { Disc3, Flame, Scissors, TrendingUp } from "lucide-react";
import { Search } from "lucide-react";
import { motion } from "motion/react";
import { useRef, useState } from "react";
import { ContentCard, ContentCardSkeleton } from "../components/ContentCard";
import { useContent } from "../hooks/use-content";
import { useDiscography } from "../hooks/use-discography";
import type { Release } from "../types";

const SKELS = ["s1", "s2", "s3", "s4", "s5", "s6", "s7", "s8"];

// ─── Hero search ──────────────────────────────────────────────────────────────
function HeroSearch() {
  const [query, setQuery] = useState("");
  const navigate = useNavigate();
  const inputRef = useRef<HTMLInputElement>(null);

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const q = query.trim();
    if (!q) return;
    navigate({ to: "/search", search: { q } });
  }

  return (
    <form
      onSubmit={handleSubmit}
      className="flex w-full max-w-xl mx-auto"
      data-ocid="hero-search-form"
    >
      <input
        ref={inputRef}
        type="search"
        placeholder="Search songs, snippets, photos, members…"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        data-ocid="hero-search-input"
        className="flex-1 min-w-0 rounded-l-full border border-border bg-card px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        aria-label="Search content"
      />
      <Button
        type="submit"
        data-ocid="hero-search-btn"
        className="rounded-r-full rounded-l-none border border-l-0 border-border bg-muted hover:bg-primary hover:text-primary-foreground px-4 transition-smooth"
        variant="ghost"
        aria-label="Submit search"
      >
        <Search className="h-4 w-4" />
      </Button>
    </form>
  );
}

// ─── Release card ─────────────────────────────────────────────────────────────
function ReleaseCard({ release }: { release: Release }) {
  return (
    <Link
      to="/releases/$releaseId"
      params={{ releaseId: release.id }}
      className="group block bg-card border border-border rounded hover:border-primary/50 transition-smooth overflow-hidden"
      data-ocid={`release-card-${release.id}`}
    >
      <div className="relative aspect-square bg-secondary overflow-hidden">
        <img
          src={release.coverUrl}
          alt={release.title}
          className="w-full h-full object-contain p-6 opacity-60 group-hover:opacity-80 transition-smooth"
        />
        <Badge className="absolute top-2 right-2 bg-primary/90 text-primary-foreground uppercase text-[10px] tracking-widest">
          {release.type}
        </Badge>
      </div>
      <div className="p-3">
        <h3 className="text-sm font-medium text-foreground truncate">
          {release.title}
        </h3>
        <p className="text-xs text-muted-foreground mt-0.5">{release.member}</p>
        <p className="text-xs text-muted-foreground">
          {new Date(release.releaseDate).toLocaleDateString()}
        </p>
      </div>
    </Link>
  );
}

// ─── Latest feed ─────────────────────────────────────────────────────────────
function LatestFeed() {
  const { getLatest } = useContent();
  const [loading] = useState(false);
  const items = getLatest(8);

  if (loading) {
    return (
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
        {SKELS.map((id) => (
          <ContentCardSkeleton key={id} />
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
      {items.map((item, i) => (
        <motion.div
          key={item.id}
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: i * 0.06, duration: 0.35 }}
        >
          <ContentCard item={item} />
        </motion.div>
      ))}
    </div>
  );
}

// ─── Page ─────────────────────────────────────────────────────────────────────
export function HomePage() {
  const { getLatest } = useContent();
  const { getLatest: getLatestReleases } = useDiscography();
  const latestReleases = getLatestReleases(4);
  const snippets = getLatest(8).filter(
    (c) => c.type === "snippet" || c.type === "leak",
  );

  return (
    <div className="flex flex-col gap-0">
      {/* ── Hero ── */}
      <section className="relative bg-card border-b border-border overflow-hidden">
        <div
          aria-hidden
          className="pointer-events-none absolute inset-0 bg-gradient-to-br from-primary/10 via-transparent to-background/50"
        />

        <div className="relative z-10 mx-auto max-w-5xl px-6 py-12 md:py-16 flex flex-col items-center gap-6 text-center">
          <motion.img
            src="/assets/generated/dvc-logo-transparent.dim_280x80.png"
            alt="deathVail Coven"
            className="h-14 md:h-20 object-contain drop-shadow-lg"
            initial={{ opacity: 0, scale: 0.92 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
          />

          <motion.div
            className="flex items-center gap-2"
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.15, duration: 0.4 }}
          >
            <Flame className="w-4 h-4 text-primary" />
            <span className="text-xs uppercase tracking-widest text-primary font-medium">
              Official DVC hub
            </span>
          </motion.div>

          <motion.p
            className="text-muted-foreground text-sm md:text-base max-w-md leading-relaxed"
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.25, duration: 0.4 }}
          >
            Songs, snippets, leaks, photos &amp; videos — all in one place.
          </motion.p>

          <motion.div
            className="w-full"
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.35, duration: 0.4 }}
          >
            <HeroSearch />
          </motion.div>

          <motion.div
            className="flex flex-wrap gap-3 justify-center"
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.45, duration: 0.4 }}
          >
            <Link
              to="/releases"
              className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded text-sm font-medium hover:bg-primary/80 transition-smooth"
              data-ocid="hero-releases-cta"
            >
              <Disc3 className="w-4 h-4" />
              New Releases
            </Link>
            <Link
              to="/latest"
              className="flex items-center gap-2 px-4 py-2 bg-secondary border border-border text-foreground rounded text-sm hover:bg-muted transition-smooth"
              data-ocid="hero-latest-cta"
            >
              <TrendingUp className="w-4 h-4" />
              Latest Stuff
            </Link>
          </motion.div>
        </div>
      </section>

      {/* ── Latest Posts ── */}
      <section className="px-6 py-8 bg-background">
        <div className="flex items-center justify-between mb-5">
          <h2 className="text-lg font-display font-bold text-foreground flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-primary" />
            Latest Posts
          </h2>
          <Link
            to="/latest"
            className="text-xs text-primary hover:text-primary/80 transition-colors"
            data-ocid="home-latest-link"
          >
            See all →
          </Link>
        </div>
        <LatestFeed />
      </section>

      {/* ── New Releases ── */}
      <section className="px-6 py-8 bg-muted/10 border-t border-border">
        <div className="flex items-center justify-between mb-5">
          <h2 className="text-lg font-display font-bold text-foreground flex items-center gap-2">
            <Disc3 className="w-5 h-5 text-primary" />
            New Releases
          </h2>
          <Link
            to="/releases"
            className="text-xs text-primary hover:text-primary/80 transition-colors"
            data-ocid="home-releases-link"
          >
            Full discography →
          </Link>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
          {latestReleases.map((release) => (
            <ReleaseCard key={release.id} release={release} />
          ))}
        </div>
      </section>

      {/* ── Snippets ── */}
      {snippets.length > 0 && (
        <section className="px-6 py-8 bg-background border-t border-border">
          <div className="flex items-center justify-between mb-5">
            <h2 className="text-lg font-display font-bold text-foreground flex items-center gap-2">
              <Scissors className="w-5 h-5 text-primary" />
              Latest Snippets
            </h2>
            <Link
              to="/snippets"
              className="text-xs text-primary hover:text-primary/80 transition-colors"
              data-ocid="home-snippets-link"
            >
              All snippets →
            </Link>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
            {snippets.slice(0, 4).map((item) => (
              <ContentCard key={item.id} item={item} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
