import { Link } from "@tanstack/react-router";
import { Clock, Zap } from "lucide-react";
import { ContentCard, ContentCardSkeleton } from "../components/ContentCard";
import { useContent } from "../hooks/use-content";

const SKELETON_IDS = ["s1", "s2", "s3", "s4", "s5", "s6", "s7", "s8"];

export function LatestPage() {
  const { content } = useContent();

  const sorted = [...content].sort(
    (a, b) =>
      new Date(b.releaseDate).getTime() - new Date(a.releaseDate).getTime(),
  );

  return (
    <div className="px-4 md:px-6 py-8">
      {/* Page header */}
      <div className="flex items-start justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-display font-bold text-foreground flex items-center gap-2 mb-1">
            <Zap className="w-6 h-6 text-primary" />
            Latest Stuff
          </h1>
          <p className="text-muted-foreground text-sm flex items-center gap-1.5">
            <Clock className="w-3.5 h-3.5" />
            <span
              className="font-semibold text-foreground"
              data-ocid="latest-count"
            >
              {sorted.length}
            </span>{" "}
            {sorted.length === 1 ? "item" : "items"}, newest first
          </p>
        </div>
        <Link
          to="/"
          className="text-xs text-muted-foreground hover:text-foreground transition-colors shrink-0 mt-1"
          data-ocid="latest-home-link"
        >
          ← Home
        </Link>
      </div>

      {/* Grid */}
      {sorted.length === 0 ? (
        <div
          className="text-center py-24 flex flex-col items-center gap-4"
          data-ocid="latest-empty"
        >
          <div className="rounded-full bg-muted w-16 h-16 flex items-center justify-center">
            <Zap className="w-7 h-7 text-muted-foreground opacity-40" />
          </div>
          <div>
            <p className="text-foreground font-medium">Nothing here yet</p>
            <p className="text-muted-foreground text-sm mt-1">
              The Coven hasn't posted anything. Check back soon.
            </p>
          </div>
          <Link
            to="/"
            className="text-primary text-sm hover:underline"
            data-ocid="latest-empty-cta"
          >
            ← Back to Home
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 xl:grid-cols-5 gap-4">
          {sorted.map((item) => (
            <ContentCard key={item.id} item={item} />
          ))}
        </div>
      )}
    </div>
  );
}

export function LatestPageSkeleton() {
  return (
    <div className="px-4 md:px-6 py-8">
      <div className="h-8 w-48 bg-muted rounded mb-6 animate-pulse" />
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 xl:grid-cols-5 gap-4">
        {SKELETON_IDS.map((id) => (
          <ContentCardSkeleton key={id} />
        ))}
      </div>
    </div>
  );
}
