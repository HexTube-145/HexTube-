import { Badge } from "@/components/ui/badge";
import { Link, useParams } from "@tanstack/react-router";
import { ChevronLeft, Disc3, Zap } from "lucide-react";
import { useContent } from "../hooks/use-content";
import { useDiscography } from "../hooks/use-discography";
import { useMembers } from "../hooks/use-members";
import type { ContentItem, MemberHandle, Release } from "../types";

const TYPE_COLORS: Record<string, string> = {
  song: "bg-primary/20 text-primary border-primary/30",
  snippet: "bg-accent/20 text-accent border-accent/30",
  leak: "bg-destructive/20 text-destructive border-destructive/30",
  photo: "bg-secondary text-secondary-foreground border-border",
  video: "bg-blue-900/30 text-blue-300 border-blue-800/40",
};

function MiniContentCard({ item }: { item: ContentItem }) {
  return (
    <div className="bg-card border border-border rounded overflow-hidden hover:border-primary/40 transition-smooth shadow-card">
      <div className="relative aspect-video bg-secondary overflow-hidden">
        <img
          src={item.thumbnailUrl}
          alt={item.title}
          className="w-full h-full object-contain p-3 opacity-60"
        />
        {item.duration && (
          <span className="absolute bottom-1 right-1 text-xs font-mono bg-background/80 px-1 py-0.5 rounded">
            {item.duration}
          </span>
        )}
        <span
          className={`absolute top-1.5 left-1.5 text-[10px] px-1.5 py-0.5 rounded border font-medium ${TYPE_COLORS[item.type]}`}
        >
          {item.type}
        </span>
      </div>
      <div className="p-2.5">
        <p className="text-xs font-medium text-foreground line-clamp-2">
          {item.title}
        </p>
        <p className="text-xs text-muted-foreground mt-0.5">
          {item.views.toLocaleString()} views
        </p>
      </div>
    </div>
  );
}

function MiniReleaseCard({ release }: { release: Release }) {
  return (
    <Link
      to="/releases/$releaseId"
      params={{ releaseId: release.id }}
      className="group block bg-card border border-border rounded overflow-hidden hover:border-primary/40 transition-smooth shadow-card"
    >
      <div className="relative aspect-square bg-secondary overflow-hidden">
        <img
          src={release.coverUrl}
          alt={release.title}
          className="w-full h-full object-contain p-4 opacity-60 group-hover:opacity-80 transition-smooth"
        />
        <Badge className="absolute top-1.5 right-1.5 bg-primary/90 text-primary-foreground uppercase text-[10px] tracking-widest">
          {release.type}
        </Badge>
      </div>
      <div className="p-2.5">
        <p className="text-xs font-medium text-foreground truncate">
          {release.title}
        </p>
        <p className="text-xs text-muted-foreground">
          {new Date(release.releaseDate).toLocaleDateString()}
        </p>
      </div>
    </Link>
  );
}

export function MemberPage() {
  const { handle } = useParams({ from: "/members/$handle" });
  const { getByHandle } = useMembers();
  const { getByMember } = useContent();
  const { releases } = useDiscography();

  const member = getByHandle(handle as MemberHandle);

  if (!member) {
    return (
      <div className="flex flex-col items-center justify-center py-24 gap-3">
        <p className="text-muted-foreground">Member not found.</p>
        <Link
          to="/members"
          search={{ member: "" }}
          className="text-primary text-sm hover:underline"
        >
          ← Back to Members
        </Link>
      </div>
    );
  }

  const memberContent = getByMember(handle as MemberHandle);
  const memberReleases = releases.filter((r) => r.member === handle);

  return (
    <div className="px-6 py-8">
      <Link
        to="/members"
        search={{ member: handle.toLowerCase() }}
        className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors mb-6"
        data-ocid="member-back"
      >
        <ChevronLeft className="w-4 h-4" />
        All Members
      </Link>

      {/* Profile Header */}
      <div className="flex gap-5 mb-8 p-5 bg-card border border-border rounded">
        <div className="w-20 h-20 bg-secondary rounded overflow-hidden shrink-0 border border-border">
          <img
            src={member.avatarUrl}
            alt={member.displayName}
            className="w-full h-full object-contain p-2 opacity-60"
          />
        </div>
        <div>
          <h1 className="text-2xl font-display font-bold text-foreground">
            {member.displayName}
          </h1>
          <p className="text-sm text-primary font-medium mb-2">{member.role}</p>
          <p className="text-sm text-muted-foreground leading-relaxed max-w-xl">
            {member.bio}
          </p>
          <p className="text-xs text-muted-foreground mt-2">
            Member since{" "}
            {new Date(member.joinedDate).toLocaleDateString("en-US", {
              year: "numeric",
              month: "long",
            })}
          </p>
        </div>
      </div>

      {/* Releases */}
      {memberReleases.length > 0 && (
        <section className="mb-8">
          <h2 className="text-base font-display font-bold text-foreground flex items-center gap-2 mb-4">
            <Disc3 className="w-4 h-4 text-primary" />
            Releases
          </h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
            {memberReleases.map((r) => (
              <MiniReleaseCard key={r.id} release={r} />
            ))}
          </div>
        </section>
      )}

      {/* Content */}
      {memberContent.length > 0 && (
        <section>
          <h2 className="text-base font-display font-bold text-foreground flex items-center gap-2 mb-4">
            <Zap className="w-4 h-4 text-primary" />
            Posts &amp; Media
          </h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
            {memberContent.map((c) => (
              <MiniContentCard key={c.id} item={c} />
            ))}
          </div>
        </section>
      )}

      {memberContent.length === 0 && memberReleases.length === 0 && (
        <div className="text-center py-16" data-ocid="member-empty">
          <p className="text-muted-foreground">No content posted yet.</p>
        </div>
      )}
    </div>
  );
}
