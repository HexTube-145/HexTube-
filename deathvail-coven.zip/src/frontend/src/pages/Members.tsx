import { Badge } from "@/components/ui/badge";
import { Link, useNavigate, useSearch } from "@tanstack/react-router";
import { Disc3, Users, Zap } from "lucide-react";
import { useState } from "react";
import { useContent } from "../hooks/use-content";
import { useDiscography } from "../hooks/use-discography";
import { useMembers } from "../hooks/use-members";
import type { ContentItem, Member, MemberHandle, Release } from "../types";

const MEMBER_HANDLES: MemberHandle[] = ["Otrik", "BWTCHR", "CHUCKII", "Nolon"];

const TYPE_COLORS: Record<string, string> = {
  song: "bg-primary/20 text-primary border-primary/30",
  snippet: "bg-accent/20 text-accent border-accent/30",
  leak: "bg-destructive/20 text-destructive border-destructive/30",
  photo: "bg-secondary text-secondary-foreground border-border",
  video: "bg-blue-900/30 text-blue-300 border-blue-800/40",
};

// ── SongModal ──────────────────────────────────────────────────────────────────
function SongModal({
  item,
  onClose,
}: {
  item: ContentItem;
  onClose: () => void;
}) {
  const [playing, setPlaying] = useState(false);

  // Close on backdrop click
  const handleBackdrop = (e: React.MouseEvent<HTMLDialogElement>) => {
    if (e.target === e.currentTarget) onClose();
  };

  return (
    // biome-ignore lint/a11y/useKeyWithClickEvents: <backdrop close>
    <dialog
      open
      className="fixed inset-0 z-50 flex items-center justify-center bg-background/80 backdrop-blur-sm px-4 m-0 max-w-none max-h-none w-full h-full border-0 p-0"
      onClick={handleBackdrop}
      aria-label={item.title}
    >
      <div className="bg-card border border-border rounded-lg w-full max-w-md shadow-2xl overflow-hidden">
        {/* Thumbnail */}
        <div className="relative aspect-video bg-secondary overflow-hidden">
          <img
            src={item.thumbnailUrl}
            alt={item.title}
            className="w-full h-full object-contain p-6 opacity-70"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-card/90 to-transparent" />
          <span
            className={`absolute top-2 left-2 text-xs px-2 py-0.5 rounded border font-medium ${TYPE_COLORS[item.type]}`}
          >
            {item.type}
          </span>
        </div>

        <div className="p-5">
          <h2 className="text-lg font-display font-bold text-foreground mb-1">
            {item.title}
          </h2>
          <p className="text-sm text-muted-foreground mb-4">
            {item.description}
          </p>

          <dl className="grid grid-cols-2 gap-x-4 gap-y-2 text-xs mb-5">
            <div>
              <dt className="text-muted-foreground">Release date</dt>
              <dd className="text-foreground font-medium">
                {new Date(item.releaseDate).toLocaleDateString("en-US", {
                  year: "numeric",
                  month: "long",
                  day: "numeric",
                })}
              </dd>
            </div>
            {item.duration && (
              <div>
                <dt className="text-muted-foreground">Duration</dt>
                <dd className="text-foreground font-mono font-medium">
                  {item.duration}
                </dd>
              </div>
            )}
            <div>
              <dt className="text-muted-foreground">By</dt>
              <dd className="text-foreground font-medium">{item.member}</dd>
            </div>
            <div>
              <dt className="text-muted-foreground">Views</dt>
              <dd className="text-foreground font-medium">
                {item.views.toLocaleString()}
              </dd>
            </div>
          </dl>

          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => setPlaying((p) => !p)}
              className="flex-1 flex items-center justify-center gap-2 h-9 rounded bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors"
              data-ocid="song-modal-play"
              aria-label={playing ? "Pause" : "Play"}
            >
              {playing ? (
                <>
                  <span className="w-3.5 h-3.5 flex gap-0.5">
                    <span className="w-1 h-full bg-current rounded-sm" />
                    <span className="w-1 h-full bg-current rounded-sm" />
                  </span>
                  Pause
                </>
              ) : (
                <>
                  <span className="w-0 h-0 border-t-[6px] border-t-transparent border-b-[6px] border-b-transparent border-l-[10px] border-l-current" />
                  Play
                </>
              )}
            </button>
            <button
              type="button"
              onClick={onClose}
              className="px-4 h-9 rounded border border-border text-sm text-muted-foreground hover:text-foreground hover:border-foreground/30 transition-colors"
              data-ocid="song-modal-close"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </dialog>
  );
}

// ── ContentCard ────────────────────────────────────────────────────────────────
function ContentCard({
  item,
  onSelect,
}: {
  item: ContentItem;
  onSelect: (item: ContentItem) => void;
}) {
  return (
    <button
      type="button"
      onClick={() => onSelect(item)}
      className="group text-left bg-card border border-border rounded hover:border-primary/50 transition-smooth cursor-pointer overflow-hidden shadow-card w-full"
      data-ocid={`member-content-card-${item.id}`}
    >
      <div className="relative aspect-video bg-secondary overflow-hidden">
        <img
          src={item.thumbnailUrl}
          alt={item.title}
          className="w-full h-full object-contain p-4 opacity-60 group-hover:opacity-80 transition-smooth"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-background/80 to-transparent" />
        {item.duration && (
          <span className="absolute bottom-1.5 right-2 text-xs font-mono bg-background/80 px-1 py-0.5 rounded text-foreground/90">
            {item.duration}
          </span>
        )}
        <span
          className={`absolute top-2 left-2 text-xs px-2 py-0.5 rounded border font-medium ${TYPE_COLORS[item.type]}`}
        >
          {item.type}
        </span>
      </div>
      <div className="p-3">
        <h3 className="text-sm font-medium text-foreground line-clamp-2 leading-snug mb-1">
          {item.title}
        </h3>
        <p className="text-xs text-muted-foreground mt-0.5">
          {item.views.toLocaleString()} views ·{" "}
          {new Date(item.releaseDate).toLocaleDateString()}
        </p>
      </div>
    </button>
  );
}

// ── MiniReleaseCard ────────────────────────────────────────────────────────────
function MiniReleaseCard({ release }: { release: Release }) {
  return (
    <Link
      to="/releases/$releaseId"
      params={{ releaseId: release.id }}
      className="group block bg-card border border-border rounded overflow-hidden hover:border-primary/40 transition-smooth shadow-card"
      data-ocid={`member-release-card-${release.id}`}
    >
      <div className="relative aspect-square bg-secondary overflow-hidden">
        <img
          src={release.coverUrl}
          alt={release.title}
          className="w-full h-full object-contain p-4 opacity-60 group-hover:opacity-80 transition-smooth"
        />
        <Badge className="absolute top-1.5 right-1.5 bg-primary/90 text-primary-foreground uppercase text-[10px] tracking-widest">
          {release.type}
        </Badge>
      </div>
      <div className="p-2.5">
        <p className="text-xs font-medium text-foreground truncate">
          {release.title}
        </p>
        <p className="text-xs text-muted-foreground">
          {new Date(release.releaseDate).toLocaleDateString()}
        </p>
      </div>
    </Link>
  );
}

// ── MemberTab content panel ────────────────────────────────────────────────────
function MemberPanel({
  member,
  content,
  releases,
  onSelectContent,
}: {
  member: Member;
  content: ContentItem[];
  releases: Release[];
  onSelectContent: (item: ContentItem) => void;
}) {
  return (
    <div className="py-6">
      {/* Member header */}
      <div className="flex items-center gap-4 mb-6 p-4 bg-card border border-border rounded-lg">
        <div className="w-16 h-16 rounded-full bg-secondary border border-border overflow-hidden shrink-0">
          <img
            src={member.avatarUrl}
            alt={member.displayName}
            className="w-full h-full object-contain p-1.5 opacity-60"
          />
        </div>
        <div className="min-w-0">
          <h2 className="text-xl font-display font-bold text-foreground">
            {member.displayName}
          </h2>
          <p className="text-sm text-primary font-medium">{member.role}</p>
          <p className="text-sm text-muted-foreground mt-1 line-clamp-2 leading-relaxed">
            {member.bio}
          </p>
        </div>
        <div className="ml-auto shrink-0 text-right hidden sm:block">
          <span className="text-2xl font-display font-bold text-foreground">
            {content.length + releases.length}
          </span>
          <p className="text-xs text-muted-foreground">uploads</p>
        </div>
      </div>

      {/* Releases */}
      {releases.length > 0 && (
        <section className="mb-8">
          <h3 className="text-sm font-display font-bold text-foreground flex items-center gap-2 mb-3">
            <Disc3 className="w-4 h-4 text-primary" />
            Releases
            <span className="text-xs text-muted-foreground font-normal">
              ({releases.length})
            </span>
          </h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
            {releases.map((r) => (
              <MiniReleaseCard key={r.id} release={r} />
            ))}
          </div>
        </section>
      )}

      {/* Content */}
      {content.length > 0 && (
        <section>
          <h3 className="text-sm font-display font-bold text-foreground flex items-center gap-2 mb-3">
            <Zap className="w-4 h-4 text-primary" />
            Posts &amp; Media
            <span className="text-xs text-muted-foreground font-normal">
              ({content.length})
            </span>
          </h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
            {content.map((item) => (
              <ContentCard
                key={item.id}
                item={item}
                onSelect={onSelectContent}
              />
            ))}
          </div>
        </section>
      )}

      {content.length === 0 && releases.length === 0 && (
        <div
          className="text-center py-16 text-muted-foreground"
          data-ocid="member-tab-empty"
        >
          <p className="text-base mb-1">No content yet.</p>
          <p className="text-sm">Check back soon.</p>
        </div>
      )}
    </div>
  );
}

// ── Main Page ──────────────────────────────────────────────────────────────────
export function MembersPage() {
  const { members, getByHandle } = useMembers();
  const { getByMember } = useContent();
  const { releases } = useDiscography();
  const navigate = useNavigate({ from: "/members" });
  const search = useSearch({ from: "/members" });

  const rawMember = search.member ?? "";
  const validHandles = MEMBER_HANDLES.map((h) => h.toLowerCase());
  const activeHandle: MemberHandle = validHandles.includes(
    rawMember.toLowerCase(),
  )
    ? (MEMBER_HANDLES.find(
        (h) => h.toLowerCase() === rawMember.toLowerCase(),
      ) ?? MEMBER_HANDLES[0])
    : MEMBER_HANDLES[0];

  const [selectedContent, setSelectedContent] = useState<ContentItem | null>(
    null,
  );

  const activeMember = getByHandle(activeHandle);

  const setActiveHandle = (handle: MemberHandle) => {
    navigate({ search: { member: handle.toLowerCase() } });
  };

  const memberContent = getByMember(activeHandle);
  const memberReleases = releases.filter((r) => r.member === activeHandle);

  return (
    <div className="px-6 py-8">
      {/* Page header */}
      <h1 className="text-2xl font-display font-bold text-foreground flex items-center gap-2 mb-1">
        <Users className="w-6 h-6 text-primary" />
        Members
      </h1>
      <p className="text-muted-foreground text-sm mb-6">
        Meet the four artists behind deathVail Coven.
      </p>

      {/* Tab bar */}
      <div
        className="flex border-b border-border gap-0 mb-0"
        role="tablist"
        aria-label="Member tabs"
        data-ocid="member-tabs"
      >
        {members
          .filter((m) => MEMBER_HANDLES.includes(m.handle))
          .map((member) => {
            const isActive = member.handle === activeHandle;
            return (
              <button
                key={member.handle}
                type="button"
                role="tab"
                aria-selected={isActive}
                aria-controls={`panel-${member.handle}`}
                onClick={() => setActiveHandle(member.handle)}
                className={[
                  "px-5 py-3 text-sm font-medium transition-colors relative whitespace-nowrap",
                  isActive
                    ? "text-primary after:absolute after:bottom-0 after:inset-x-0 after:h-0.5 after:bg-primary"
                    : "text-muted-foreground hover:text-foreground",
                ].join(" ")}
                data-ocid={`tab-${member.handle.toLowerCase()}`}
              >
                {member.displayName}
              </button>
            );
          })}
      </div>

      {/* Active member panel */}
      {activeMember && (
        <div
          id={`panel-${activeHandle}`}
          role="tabpanel"
          aria-label={`${activeMember.displayName}'s content`}
        >
          <MemberPanel
            member={activeMember}
            content={memberContent}
            releases={memberReleases}
            onSelectContent={setSelectedContent}
          />
        </div>
      )}

      {/* Song modal */}
      {selectedContent && (
        <SongModal
          item={selectedContent}
          onClose={() => setSelectedContent(null)}
        />
      )}
    </div>
  );
}
