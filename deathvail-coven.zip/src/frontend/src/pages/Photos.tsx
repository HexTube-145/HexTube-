import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "@tanstack/react-router";
import { Camera, ImageIcon } from "lucide-react";
import { useContent } from "../hooks/use-content";
import type { ContentItem } from "../types";

const SKELETON_IDS = ["s1", "s2", "s3", "s4", "s5", "s6", "s7", "s8", "s9"];

function PhotoCard({ item }: { item: ContentItem }) {
  return (
    <div
      className="group relative overflow-hidden rounded-md bg-card border border-border hover:border-primary/50 transition-smooth cursor-pointer"
      data-ocid={`photo-card-${item.id}`}
    >
      {/* Large image — 4:3 aspect for more photo real-estate */}
      <div className="aspect-[4/3] w-full overflow-hidden bg-muted">
        <img
          src={item.thumbnailUrl}
          alt={item.title}
          loading="lazy"
          className="w-full h-full object-cover transition-smooth group-hover:scale-105"
        />
      </div>

      {/* Hover overlay with caption */}
      <div className="absolute inset-0 bg-gradient-to-t from-background/90 via-background/20 to-transparent opacity-0 group-hover:opacity-100 transition-smooth flex flex-col justify-end p-3">
        <p
          className="text-sm font-semibold text-foreground line-clamp-2 leading-snug"
          title={item.title}
        >
          {item.title}
        </p>
        <p className="text-xs text-muted-foreground mt-0.5">
          {item.member === "deathVailCoven" ? "deathVail Coven" : item.member}
        </p>
        <p className="text-xs text-muted-foreground">
          {new Date(item.releaseDate).toLocaleDateString("en-US", {
            month: "short",
            day: "numeric",
            year: "numeric",
          })}
        </p>
      </div>

      {/* Always-visible bottom strip */}
      <div className="px-2 py-2 border-t border-border bg-card group-hover:opacity-0 transition-smooth">
        <p className="text-xs font-medium text-foreground truncate">
          {item.title}
        </p>
        <p className="text-xs text-muted-foreground truncate">
          {item.member === "deathVailCoven" ? "deathVail Coven" : item.member} ·{" "}
          {new Date(item.releaseDate).toLocaleDateString("en-US", {
            month: "short",
            year: "numeric",
          })}
        </p>
      </div>
    </div>
  );
}

export function PhotosPage() {
  const { getByType } = useContent();
  const photos = getByType("photo").sort(
    (a, b) =>
      new Date(b.releaseDate).getTime() - new Date(a.releaseDate).getTime(),
  );

  return (
    <div className="px-4 md:px-6 py-8">
      {/* Page header */}
      <div className="flex items-start justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-display font-bold text-foreground flex items-center gap-2 mb-1">
            <Camera className="w-6 h-6 text-primary" />
            Photos
          </h1>
          <p className="text-muted-foreground text-sm flex items-center gap-1.5">
            <ImageIcon className="w-3.5 h-3.5" />
            <span
              className="font-semibold text-foreground"
              data-ocid="photos-count"
            >
              {photos.length}
            </span>{" "}
            {photos.length === 1 ? "photo" : "photos"} from the Coven
          </p>
        </div>
        <Link
          to="/"
          className="text-xs text-muted-foreground hover:text-foreground transition-colors shrink-0 mt-1"
          data-ocid="photos-home-link"
        >
          ← Home
        </Link>
      </div>

      {/* Grid — larger tiles for visual impact */}
      {photos.length === 0 ? (
        <div
          className="text-center py-24 flex flex-col items-center gap-4"
          data-ocid="photos-empty"
        >
          <div className="rounded-full bg-muted w-16 h-16 flex items-center justify-center">
            <Camera className="w-7 h-7 text-muted-foreground opacity-40" />
          </div>
          <div>
            <p className="text-foreground font-medium">No photos yet</p>
            <p className="text-muted-foreground text-sm mt-1">
              Behind-the-scenes and studio shots will appear here.
            </p>
          </div>
          <Link
            to="/"
            className="text-primary text-sm hover:underline"
            data-ocid="photos-empty-cta"
          >
            ← Back to Home
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {photos.map((item) => (
            <PhotoCard key={item.id} item={item} />
          ))}
        </div>
      )}
    </div>
  );
}

export function PhotosPageSkeleton() {
  return (
    <div className="px-4 md:px-6 py-8">
      <div className="h-8 w-36 bg-muted rounded mb-6 animate-pulse" />
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {SKELETON_IDS.map((id) => (
          <Skeleton key={id} className="aspect-[4/3] w-full rounded-md" />
        ))}
      </div>
    </div>
  );
}
