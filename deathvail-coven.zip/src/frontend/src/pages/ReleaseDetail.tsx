import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import { Link, useParams } from "@tanstack/react-router";
import { ArrowLeft, Calendar, Disc3, Music2 } from "lucide-react";
import { useState } from "react";
import { SongModal } from "../components/SongModal";
import { useDiscography } from "../hooks/use-discography";
import type { Track } from "../types";

const TYPE_LABELS: Record<string, string> = {
  album: "Album",
  ep: "EP",
  single: "Single",
};

function formatDate(dateStr: string): string {
  return new Date(dateStr).toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });
}

function TrackRow({
  track,
  onClick,
}: {
  track: Track;
  onClick: (t: Track) => void;
}) {
  return (
    <button
      type="button"
      className="w-full flex items-center gap-4 px-4 py-3 rounded-lg hover:bg-muted/60 active:bg-muted transition-smooth text-left group"
      onClick={() => onClick(track)}
      data-ocid={`track-row-${track.id}`}
      aria-label={`View details for ${track.title}`}
    >
      <span className="w-6 text-right text-sm text-muted-foreground font-mono shrink-0 group-hover:text-primary transition-colors">
        {track.trackNumber}
      </span>
      <Music2 className="h-4 w-4 text-muted-foreground shrink-0 group-hover:text-primary transition-colors" />
      <span className="flex-1 min-w-0 font-body font-medium text-foreground truncate group-hover:text-primary transition-colors">
        {track.title}
      </span>
      <span className="text-sm text-muted-foreground font-mono shrink-0">
        {track.duration}
      </span>
    </button>
  );
}

function ReleaseSkeleton() {
  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-8 space-y-6">
      <Skeleton className="h-6 w-28" />
      <div className="flex gap-6">
        <Skeleton className="h-44 w-44 rounded-xl shrink-0" />
        <div className="space-y-3 flex-1 pt-2">
          <Skeleton className="h-5 w-16" />
          <Skeleton className="h-8 w-3/4" />
          <Skeleton className="h-4 w-28" />
          <Skeleton className="h-4 w-48" />
          <Skeleton className="h-16 w-full mt-2" />
        </div>
      </div>
      <Skeleton className="h-px w-full" />
      <div className="space-y-2">
        {[1, 2, 3, 4].map((i) => (
          <Skeleton key={i} className="h-12 rounded-lg" />
        ))}
      </div>
    </div>
  );
}

export function ReleasePage() {
  const { releaseId } = useParams({ from: "/releases/$releaseId" });
  const { getById } = useDiscography();
  const [selectedTrack, setSelectedTrack] = useState<Track | null>(null);

  const release = getById(releaseId);

  if (!release) return <ReleaseSkeleton />;

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-8">
      {/* Back navigation */}
      <Link
        to="/releases"
        className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors mb-6 group"
        data-ocid="release-back-btn"
      >
        <ArrowLeft className="h-4 w-4 group-hover:-translate-x-0.5 transition-transform" />
        Back to Releases
      </Link>

      {/* Release header */}
      <div className="flex flex-col sm:flex-row gap-6 mb-6">
        {/* Cover art */}
        <div className="shrink-0 self-start">
          <div className="w-44 h-44 sm:w-52 sm:h-52 rounded-xl overflow-hidden border border-border shadow-lg bg-muted/40 flex items-center justify-center">
            {release.coverUrl ? (
              <img
                src={release.coverUrl}
                alt={`${release.title} cover art`}
                className="w-full h-full object-contain p-4 opacity-80"
              />
            ) : (
              <Disc3 className="h-16 w-16 text-muted-foreground opacity-40" />
            )}
          </div>
        </div>

        {/* Meta */}
        <div className="flex-1 min-w-0 flex flex-col justify-end gap-2">
          <Badge
            variant="secondary"
            className="w-fit uppercase text-xs tracking-widest font-body"
          >
            {TYPE_LABELS[release.type] ?? release.type}
          </Badge>

          <h1
            className="font-display text-2xl sm:text-3xl font-bold text-foreground leading-tight break-words"
            data-ocid="release-title"
          >
            {release.title}
          </h1>

          <p className="text-sm font-medium text-foreground/80">
            {release.member}
          </p>

          <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-muted-foreground">
            <span className="flex items-center gap-1.5">
              <Calendar className="h-3.5 w-3.5 shrink-0" />
              {formatDate(release.releaseDate)}
            </span>
            <span className="flex items-center gap-1.5">
              <Music2 className="h-3.5 w-3.5 shrink-0" />
              {release.tracklist.length}{" "}
              {release.tracklist.length === 1 ? "track" : "tracks"}
            </span>
          </div>

          {release.description && (
            <p className="text-sm text-muted-foreground leading-relaxed line-clamp-3 mt-1">
              {release.description}
            </p>
          )}
        </div>
      </div>

      <Separator className="mb-6" />

      {/* Tracklist */}
      <section aria-label="Tracklist">
        <h2 className="text-xs font-body font-semibold text-muted-foreground uppercase tracking-widest mb-3 flex items-center gap-2">
          <Music2 className="h-3.5 w-3.5" />
          Tracklist
        </h2>

        {release.tracklist.length === 0 ? (
          <div
            className="text-center py-12 text-muted-foreground"
            data-ocid="tracklist-empty"
          >
            <Music2 className="h-10 w-10 mx-auto mb-3 opacity-30" />
            <p className="text-sm">No tracks listed yet.</p>
          </div>
        ) : (
          <div
            className="bg-card rounded-xl border border-border overflow-hidden divide-y divide-border/40"
            data-ocid="tracklist"
          >
            {release.tracklist
              .slice()
              .sort((a, b) => a.trackNumber - b.trackNumber)
              .map((track) => (
                <TrackRow
                  key={track.id}
                  track={track}
                  onClick={setSelectedTrack}
                />
              ))}
          </div>
        )}
      </section>

      {/* Song modal overlay */}
      <SongModal
        track={selectedTrack}
        releaseTitle={release.title}
        onClose={() => setSelectedTrack(null)}
      />
    </div>
  );
}
