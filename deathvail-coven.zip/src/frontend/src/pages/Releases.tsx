import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useNavigate } from "@tanstack/react-router";
import { Calendar, Clock, Disc3, Music2, Play, X } from "lucide-react";
import { AnimatePresence, motion } from "motion/react";
import { useState } from "react";
import { useDiscography } from "../hooks/use-discography";
import type { Release, ReleaseType, Track } from "../types";

// ─── Filter tabs ──────────────────────────────────────────────────────────────
type FilterTab = "all" | ReleaseType;

const TABS: { label: string; value: FilterTab }[] = [
  { label: "All", value: "all" },
  { label: "Albums", value: "album" },
  { label: "EPs", value: "ep" },
  { label: "Singles", value: "single" },
];

const TYPE_LABEL: Record<ReleaseType, string> = {
  album: "Album",
  ep: "EP",
  single: "Single",
};

// ─── Helpers ──────────────────────────────────────────────────────────────────
function formatDate(iso: string) {
  return new Date(iso).toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });
}

// Silence unused-variable lint; kept for future real-backend hook wiring
function _totalDuration(tracks: Track[]): string {
  let total = 0;
  for (const t of tracks) {
    const [m, s] = t.duration.split(":").map(Number);
    total += (m ?? 0) * 60 + (s ?? 0);
  }
  const mins = Math.floor(total / 60);
  const secs = total % 60;
  return `${mins}:${secs.toString().padStart(2, "0")}`;
}

// ─── Song Detail Modal ────────────────────────────────────────────────────────
interface SongModalProps {
  release: Release;
  onClose: () => void;
}

function SongModal({ release, onClose }: SongModalProps) {
  const [playing, setPlaying] = useState(false);
  const track = release.tracklist[0];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* backdrop */}
      <button
        type="button"
        aria-label="Close modal"
        className="absolute inset-0 bg-black/70 backdrop-blur-sm cursor-default"
        onClick={onClose}
        data-ocid="song-modal-overlay"
      />
      <motion.div
        initial={{ opacity: 0, scale: 0.92, y: 24 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.88, y: 16 }}
        transition={{ type: "spring", stiffness: 300, damping: 28 }}
        className="relative w-full max-w-md bg-card border border-border rounded-lg overflow-hidden shadow-2xl"
        onClick={(e) => e.stopPropagation()}
        data-ocid="song-modal"
      >
        {/* Close */}
        <button
          type="button"
          onClick={onClose}
          className="absolute top-3 right-3 z-10 rounded-full bg-background/60 p-1.5 text-muted-foreground hover:text-foreground transition-smooth"
          aria-label="Close modal"
          data-ocid="song-modal-close"
        >
          <X className="h-4 w-4" />
        </button>

        {/* Cover */}
        <div className="relative w-full aspect-square">
          <img
            src={release.coverUrl}
            alt={release.title}
            className="w-full h-full object-cover"
            onError={(e) => {
              (e.target as HTMLImageElement).src =
                "/assets/images/placeholder.svg";
            }}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-card via-transparent to-transparent" />
        </div>

        {/* Info */}
        <div className="p-5 space-y-4">
          <div>
            <Badge className="mb-2 bg-primary text-primary-foreground text-xs font-mono uppercase tracking-wider">
              {TYPE_LABEL[release.type]}
            </Badge>
            <h2 className="text-xl font-display font-bold text-foreground leading-tight">
              {release.title}
            </h2>
            <p className="text-sm text-muted-foreground mt-0.5">
              {release.member}
            </p>
          </div>

          <div className="flex items-center gap-4 text-sm text-muted-foreground">
            <span className="flex items-center gap-1.5">
              <Calendar className="h-3.5 w-3.5 text-primary" />
              {formatDate(release.releaseDate)}
            </span>
            {track && (
              <span className="flex items-center gap-1.5">
                <Clock className="h-3.5 w-3.5 text-primary" />
                {track.duration}
              </span>
            )}
          </div>

          <p className="text-sm text-muted-foreground leading-relaxed">
            {release.description}
          </p>

          {/* Play button */}
          <button
            type="button"
            onClick={() => setPlaying((p) => !p)}
            className="flex w-full items-center justify-center gap-2.5 rounded-md bg-primary text-primary-foreground py-2.5 font-medium text-sm hover:bg-accent transition-smooth"
            data-ocid="song-modal-play"
          >
            <Play className={`h-4 w-4 ${playing ? "fill-current" : ""}`} />
            {playing ? "Now Playing…" : "Play Preview"}
          </button>
        </div>
      </motion.div>
    </div>
  );
}

// ─── Release Card ─────────────────────────────────────────────────────────────
interface ReleaseCardProps {
  release: Release;
  index: number;
  onSingleClick: (release: Release) => void;
}

function ReleaseCard({ release, index, onSingleClick }: ReleaseCardProps) {
  const navigate = useNavigate();
  const isMultiTrack = release.type !== "single";

  const handleClick = () => {
    if (isMultiTrack) {
      navigate({
        to: "/releases/$releaseId",
        params: { releaseId: release.id },
      });
    } else {
      onSingleClick(release);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.07, duration: 0.35 }}
      className="group relative bg-card border border-border rounded-lg overflow-hidden cursor-pointer hover:border-primary/50 hover:shadow-lg transition-smooth"
      onClick={handleClick}
      data-ocid={`release-card-${release.id}`}
    >
      {/* Cover art */}
      <div className="relative w-full aspect-square overflow-hidden bg-muted">
        <img
          src={release.coverUrl}
          alt={release.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-smooth"
          onError={(e) => {
            (e.target as HTMLImageElement).src =
              "/assets/images/placeholder.svg";
          }}
        />
        {/* Hover overlay */}
        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/40 transition-smooth flex items-center justify-center">
          <div className="opacity-0 group-hover:opacity-100 transition-smooth">
            <div className="rounded-full bg-primary/90 p-3">
              {isMultiTrack ? (
                <Disc3 className="h-5 w-5 text-primary-foreground" />
              ) : (
                <Play className="h-5 w-5 text-primary-foreground fill-current" />
              )}
            </div>
          </div>
        </div>
        {/* Type badge */}
        <div className="absolute top-2 left-2">
          <Badge className="bg-primary text-primary-foreground text-[10px] font-mono uppercase tracking-wider px-1.5 py-0.5">
            {TYPE_LABEL[release.type]}
          </Badge>
        </div>
      </div>

      {/* Metadata */}
      <div className="p-3 space-y-1">
        <h3 className="font-display font-semibold text-foreground text-sm leading-tight line-clamp-1">
          {release.title}
        </h3>
        <p className="text-xs text-muted-foreground">{release.member}</p>
        <div className="flex items-center justify-between pt-0.5">
          <span className="text-xs text-muted-foreground flex items-center gap-1">
            <Calendar className="h-3 w-3" />
            {new Date(release.releaseDate).getFullYear()}
          </span>
          {isMultiTrack ? (
            <span className="text-xs text-muted-foreground flex items-center gap-1">
              <Music2 className="h-3 w-3" />
              {release.tracklist.length} track
              {release.tracklist.length !== 1 ? "s" : ""}
            </span>
          ) : (
            <span className="text-xs text-muted-foreground flex items-center gap-1">
              <Clock className="h-3 w-3" />
              {release.tracklist[0]?.duration ?? "—"}
            </span>
          )}
        </div>
      </div>
    </motion.div>
  );
}

// ─── Skeleton grid ────────────────────────────────────────────────────────────
const SKEL_IDS = ["a", "b", "c", "d", "e", "f", "g", "h"];

function ReleaseSkeletons() {
  return (
    <>
      {SKEL_IDS.map((id) => (
        <div
          key={id}
          className="bg-card border border-border rounded-lg overflow-hidden"
        >
          <Skeleton className="w-full aspect-square" />
          <div className="p-3 space-y-2">
            <Skeleton className="h-4 w-3/4" />
            <Skeleton className="h-3 w-1/2" />
            <Skeleton className="h-3 w-full" />
          </div>
        </div>
      ))}
    </>
  );
}

// ─── Page ─────────────────────────────────────────────────────────────────────
export function ReleasesPage() {
  const { releases, getByType } = useDiscography();
  const [filter, setFilter] = useState<FilterTab>("all");
  const [selectedSingle, setSelectedSingle] = useState<Release | null>(null);
  const isLoading = false; // swap for isLoading from real async query hook

  const filtered =
    filter === "all" ? releases : releases.filter((r) => r.type === filter);

  const albumCount = getByType("album").length;
  const epCount = getByType("ep").length;
  const singleCount = getByType("single").length;

  return (
    <div className="min-h-screen bg-background" data-ocid="releases-page">
      {/* Header band */}
      <div className="bg-card border-b border-border px-4 py-6 md:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center gap-3 mb-1">
            <Disc3 className="h-6 w-6 text-primary" />
            <h1 className="text-2xl font-display font-bold text-foreground">
              Discography
            </h1>
          </div>
          <p className="text-sm text-muted-foreground">
            {albumCount} album{albumCount !== 1 ? "s" : ""} · {epCount} EP
            {epCount !== 1 ? "s" : ""} · {singleCount} single
            {singleCount !== 1 ? "s" : ""}
          </p>
        </div>
      </div>

      {/* Filter tabs */}
      <div className="bg-card border-b border-border px-4 md:px-8 sticky top-0 z-20">
        <div className="max-w-7xl mx-auto flex gap-1 overflow-x-auto">
          {TABS.map((tab) => (
            <button
              key={tab.value}
              type="button"
              onClick={() => setFilter(tab.value)}
              className={`flex-shrink-0 px-4 py-3 text-sm font-medium border-b-2 transition-smooth ${
                filter === tab.value
                  ? "border-primary text-primary"
                  : "border-transparent text-muted-foreground hover:text-foreground hover:border-border"
              }`}
              data-ocid={`filter-tab-${tab.value}`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Grid */}
      <div className="max-w-7xl mx-auto px-4 md:px-8 py-8">
        {isLoading ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
            <ReleaseSkeletons />
          </div>
        ) : filtered.length === 0 ? (
          <div
            className="flex flex-col items-center justify-center py-24 text-center"
            data-ocid="releases-empty"
          >
            <Disc3 className="h-14 w-14 text-muted-foreground/30 mb-4" />
            <h3 className="text-lg font-display font-semibold text-foreground mb-1">
              No releases yet
            </h3>
            <p className="text-sm text-muted-foreground max-w-xs">
              {filter === "all"
                ? "No releases have been added yet. Check back soon."
                : `No ${filter}s have been added yet.`}
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
            {filtered.map((release, i) => (
              <ReleaseCard
                key={release.id}
                release={release}
                index={i}
                onSingleClick={setSelectedSingle}
              />
            ))}
          </div>
        )}
      </div>

      {/* Song detail modal */}
      <AnimatePresence>
        {selectedSingle && (
          <SongModal
            release={selectedSingle}
            onClose={() => setSelectedSingle(null)}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
