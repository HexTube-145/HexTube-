import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Link, useNavigate, useSearch } from "@tanstack/react-router";
import { Search, X } from "lucide-react";
import { useCallback, useEffect, useState } from "react";
import { ContentCard, ContentCardSkeleton } from "../components/ContentCard";
import { useContent } from "../hooks/use-content";

const SKELETON_IDS = ["s1", "s2", "s3", "s4", "s5", "s6", "s7", "s8"];

export function SearchPage() {
  const { q } = useSearch({ from: "/search" });
  const navigate = useNavigate();
  const { search, content } = useContent();

  const [inputValue, setInputValue] = useState(q ?? "");

  // Sync input when URL param changes externally
  useEffect(() => {
    setInputValue(q ?? "");
  }, [q]);

  const handleSearch = useCallback(
    (value: string) => {
      navigate({ to: "/search", search: { q: value } });
    },
    [navigate],
  );

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") handleSearch(inputValue);
  };

  const handleClear = () => {
    setInputValue("");
    handleSearch("");
  };

  const results = q ? search(q) : [];
  const hasQuery = !!q && q.trim().length > 0;

  return (
    <div className="px-4 md:px-6 py-8">
      {/* Page header + inline search */}
      <div className="mb-6">
        <h1 className="text-2xl font-display font-bold text-foreground flex items-center gap-2 mb-4">
          <Search className="w-6 h-6 text-primary" />
          Search
        </h1>

        {/* Search input */}
        <div className="relative max-w-xl">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
          <Input
            type="search"
            placeholder="Search songs, snippets, photos, members…"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyDown={handleKeyDown}
            onBlur={() => handleSearch(inputValue)}
            className="pl-9 pr-9 bg-card border-border focus:border-primary"
            data-ocid="search-input"
            aria-label="Search content"
          />
          {inputValue && (
            <button
              type="button"
              onClick={handleClear}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
              aria-label="Clear search"
              data-ocid="search-clear"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Result count / status */}
        {hasQuery && (
          <p className="text-sm text-muted-foreground mt-3 flex items-center gap-2">
            {results.length > 0 ? (
              <>
                <span
                  className="font-semibold text-foreground"
                  data-ocid="search-count"
                >
                  {results.length}
                </span>{" "}
                {results.length === 1 ? "result" : "results"} for{" "}
                <Badge
                  variant="outline"
                  className="text-xs border-border text-muted-foreground"
                >
                  {q}
                </Badge>
              </>
            ) : (
              <>
                No results for{" "}
                <Badge
                  variant="outline"
                  className="text-xs border-border text-muted-foreground"
                >
                  {q}
                </Badge>
              </>
            )}
          </p>
        )}

        {!hasQuery && (
          <p className="text-xs text-muted-foreground mt-2">
            Searching across {content.length} items — songs, snippets, photos,
            leaks, videos and more.
          </p>
        )}
      </div>

      {/* Empty state — no query */}
      {!hasQuery && (
        <div
          className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 xl:grid-cols-5 gap-4 opacity-30 pointer-events-none select-none"
          aria-hidden="true"
        >
          {SKELETON_IDS.map((id) => (
            <ContentCardSkeleton key={id} />
          ))}
        </div>
      )}

      {/* Empty state — query but no results */}
      {hasQuery && results.length === 0 && (
        <div
          className="text-center py-24 flex flex-col items-center gap-4"
          data-ocid="search-empty"
        >
          <div className="rounded-full bg-muted w-16 h-16 flex items-center justify-center">
            <Search className="w-7 h-7 text-muted-foreground opacity-40" />
          </div>
          <div>
            <p className="text-foreground font-medium">Nothing matched "{q}"</p>
            <p className="text-muted-foreground text-sm mt-1">
              Try a different song title, member name, or content type.
            </p>
          </div>
          <div className="flex gap-3 flex-wrap justify-center">
            <button
              type="button"
              onClick={handleClear}
              className="text-primary text-sm hover:underline"
              data-ocid="search-retry-cta"
            >
              Clear search
            </button>
            <Link
              to="/"
              className="text-muted-foreground text-sm hover:underline"
              data-ocid="search-home-cta"
            >
              ← Back to Home
            </Link>
          </div>
        </div>
      )}

      {/* Results grid */}
      {hasQuery && results.length > 0 && (
        <div
          className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 xl:grid-cols-5 gap-4"
          data-ocid="search-results-grid"
        >
          {results.map((item) => (
            <ContentCard key={item.id} item={item} />
          ))}
        </div>
      )}
    </div>
  );
}
