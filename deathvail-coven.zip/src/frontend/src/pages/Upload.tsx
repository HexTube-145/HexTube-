import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Link } from "@tanstack/react-router";
import {
  CheckCircle,
  CloudUpload,
  FileAudio,
  FileImage,
  FileVideo,
  Lock,
  X,
} from "lucide-react";
import { useRef, useState } from "react";
import { toast } from "sonner";
import { useAdminStatus } from "../hooks/use-admin-status";
import { useAuth } from "../hooks/use-auth";
import type { ContentType } from "../types";

const CONTENT_TYPES: {
  value: ContentType;
  label: string;
  icon: React.ElementType;
}[] = [
  { value: "song", label: "Song", icon: FileAudio },
  { value: "snippet", label: "Snippet", icon: FileAudio },
  { value: "leak", label: "Leak", icon: FileAudio },
  { value: "photo", label: "Photo", icon: FileImage },
  { value: "video", label: "Video", icon: FileVideo },
];

const ACCEPT_MAP: Record<ContentType, string> = {
  song: "audio/*",
  snippet: "audio/*",
  leak: "audio/*",
  photo: "image/*",
  video: "video/*",
};

interface FilePreview {
  name: string;
  size: string;
  type: string;
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function FileDrop({
  label,
  accept,
  value,
  onChange,
  onClear,
  ocid,
}: {
  label: string;
  accept: string;
  value: FilePreview | null;
  onChange: (file: File) => void;
  onClear: () => void;
  ocid: string;
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [dragging, setDragging] = useState(false);

  const handleFiles = (files: FileList | null) => {
    if (files?.[0]) onChange(files[0]);
  };

  return (
    // biome-ignore lint/a11y/useSemanticElements: drag-drop zone with onDrop cannot be a native button
    <div
      role="button"
      tabIndex={0}
      className={`relative border-2 border-dashed rounded transition-smooth cursor-pointer ${
        dragging
          ? "border-primary bg-primary/5"
          : "border-border hover:border-primary/50 hover:bg-card/60"
      }`}
      onDragOver={(e) => {
        e.preventDefault();
        setDragging(true);
      }}
      onDragLeave={() => setDragging(false)}
      onDrop={(e) => {
        e.preventDefault();
        setDragging(false);
        handleFiles(e.dataTransfer.files);
      }}
      onClick={() => inputRef.current?.click()}
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          inputRef.current?.click();
        }
      }}
      data-ocid={ocid}
    >
      <input
        ref={inputRef}
        type="file"
        accept={accept}
        className="hidden"
        onChange={(e) => handleFiles(e.target.files)}
        data-ocid={`${ocid}-input`}
      />
      {value ? (
        <div className="flex items-center justify-between p-4 gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <CheckCircle className="w-5 h-5 text-primary shrink-0" />
            <div className="min-w-0">
              <p className="text-sm font-medium text-foreground truncate">
                {value.name}
              </p>
              <p className="text-xs text-muted-foreground">{value.size}</p>
            </div>
          </div>
          <button
            type="button"
            aria-label="Remove file"
            onClick={(e) => {
              e.stopPropagation();
              onClear();
            }}
            className="shrink-0 text-muted-foreground hover:text-destructive transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      ) : (
        <div className="flex flex-col items-center gap-2 py-8 px-4 text-center">
          <CloudUpload className="w-8 h-8 text-muted-foreground opacity-50" />
          <p className="text-sm text-muted-foreground">
            <span className="text-primary font-medium">Click to choose</span> or
            drag &amp; drop
          </p>
          <p className="text-xs text-muted-foreground">{label}</p>
        </div>
      )}
    </div>
  );
}

export function UploadPage() {
  const { isLoggedIn, isLoading } = useAuth();
  const { isAdmin, isChecking } = useAdminStatus();

  const [contentType, setContentType] = useState<ContentType>("song");
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [releaseDate, setReleaseDate] = useState("");
  const [duration, setDuration] = useState("");
  const [mediaFile, setMediaFile] = useState<File | null>(null);
  const [mediaPreview, setMediaPreview] = useState<FilePreview | null>(null);
  const [coverPreview, setCoverPreview] = useState<FilePreview | null>(null);
  const [uploading, setUploading] = useState(false);
  const [done, setDone] = useState(false);

  const handleMediaChange = (file: File) => {
    setMediaFile(file);
    setMediaPreview({
      name: file.name,
      size: formatBytes(file.size),
      type: file.type,
    });
  };

  const handleCoverChange = (file: File) => {
    setCoverPreview({
      name: file.name,
      size: formatBytes(file.size),
      type: file.type,
    });
  };

  const resetForm = () => {
    setTitle("");
    setDescription("");
    setReleaseDate("");
    setDuration("");
    setMediaFile(null);
    setMediaPreview(null);
    setCoverPreview(null);
    setDone(false);
    setContentType("song");
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      toast.error("Title is required.");
      return;
    }
    if (!mediaFile) {
      toast.error("Please select a media file.");
      return;
    }

    setUploading(true);
    try {
      // TODO: wire to actor.uploadContent() via object-storage ExternalBlob
      // const bytes = new Uint8Array(await mediaFile.arrayBuffer());
      // const mediaBlob = ExternalBlob.fromBytes(bytes);
      // await actor.uploadContent({ type: contentType, title, description, media: mediaBlob, ... });
      await new Promise((r) => setTimeout(r, 1200));
      setDone(true);
      toast.success("Content uploaded successfully!");
    } catch {
      toast.error("Upload failed. Please try again.");
    } finally {
      setUploading(false);
    }
  };

  if (isLoading || isChecking) {
    return (
      <div className="flex items-center justify-center py-24">
        <div className="w-8 h-8 rounded-full border-2 border-primary border-t-transparent animate-spin" />
      </div>
    );
  }

  if (!isLoggedIn) {
    return (
      <div
        className="flex flex-col items-center justify-center py-24 gap-4"
        data-ocid="upload-locked"
      >
        <Lock className="w-12 h-12 text-muted-foreground opacity-40" />
        <h2 className="text-xl font-display font-bold text-foreground">
          Sign In Required
        </h2>
        <p className="text-muted-foreground text-sm text-center max-w-xs">
          You must be signed in and approved as an admin to upload content. No
          one gets upload access automatically — an admin must approve you
          first.
        </p>
        <Link
          to="/"
          className="px-4 py-2 bg-primary text-primary-foreground rounded text-sm hover:bg-primary/80 transition-smooth"
        >
          ← Back to Home
        </Link>
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div
        className="flex flex-col items-center justify-center py-24 gap-4"
        data-ocid="upload-locked"
      >
        <Lock className="w-12 h-12 text-muted-foreground opacity-40" />
        <h2 className="text-xl font-display font-bold text-foreground">
          Admin Access Only
        </h2>
        <p className="text-muted-foreground text-sm text-center max-w-xs">
          Only approved admins can upload content. Contact an existing admin to
          request access — no one gets upload access automatically.
        </p>
        <Link
          to="/"
          className="px-4 py-2 bg-primary text-primary-foreground rounded text-sm hover:bg-primary/80 transition-smooth"
        >
          ← Back to Home
        </Link>
      </div>
    );
  }

  if (done) {
    return (
      <div
        className="flex flex-col items-center justify-center py-24 gap-4"
        data-ocid="upload-success"
      >
        <CheckCircle className="w-12 h-12 text-primary" />
        <h2 className="text-xl font-display font-bold text-foreground">
          Upload Complete!
        </h2>
        <p className="text-muted-foreground text-sm text-center max-w-xs">
          Your content has been uploaded and will appear on the site shortly.
        </p>
        <div className="flex gap-3">
          <Button
            type="button"
            variant="default"
            onClick={resetForm}
            className="bg-primary text-primary-foreground hover:bg-primary/80"
          >
            Upload Another
          </Button>
          <Link to="/">
            <Button type="button" variant="ghost">
              Back to Home
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  const selectedType = CONTENT_TYPES.find((t) => t.value === contentType)!;
  const mediaAccept = ACCEPT_MAP[contentType];
  const isAudio = ["song", "snippet", "leak"].includes(contentType);

  return (
    <div className="px-6 py-8 max-w-2xl">
      <div className="mb-8">
        <h1 className="text-2xl font-display font-bold text-foreground flex items-center gap-2 mb-1">
          <CloudUpload className="w-6 h-6 text-primary" />
          Upload Content
        </h1>
        <p className="text-muted-foreground text-sm">
          Add new music, photos, or videos to the deathVail Coven site.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="flex flex-col gap-6">
        {/* Content Type selector */}
        <div className="flex flex-col gap-2">
          <Label className="text-sm font-medium text-foreground">
            Content Type <span className="text-destructive">*</span>
          </Label>
          <div
            className="flex flex-wrap gap-2"
            data-ocid="content-type-selector"
          >
            {CONTENT_TYPES.map(({ value, label, icon: Icon }) => (
              <button
                key={value}
                type="button"
                onClick={() => setContentType(value)}
                data-ocid={`type-btn-${value}`}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded border text-sm transition-smooth ${
                  contentType === value
                    ? "border-primary bg-primary/15 text-primary font-medium"
                    : "border-border bg-card text-muted-foreground hover:border-primary/50 hover:text-foreground"
                }`}
              >
                <Icon className="w-4 h-4" />
                {label}
              </button>
            ))}
          </div>
          <p className="text-xs text-muted-foreground">
            Selected:{" "}
            <Badge className="bg-primary/20 text-primary border-primary/30 text-xs">
              <selectedType.icon className="w-3 h-3 mr-1" />
              {selectedType.label}
            </Badge>
          </p>
        </div>

        {/* Title */}
        <div className="flex flex-col gap-2">
          <Label
            htmlFor="upload-title"
            className="text-sm font-medium text-foreground"
          >
            Title <span className="text-destructive">*</span>
          </Label>
          <Input
            id="upload-title"
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder={`e.g. Veil of Ashes${contentType === "snippet" ? " (Snippet)" : ""}`}
            required
            className="bg-card border-border text-foreground placeholder:text-muted-foreground focus:border-primary"
            data-ocid="upload-title"
          />
        </div>

        {/* Description */}
        <div className="flex flex-col gap-2">
          <Label
            htmlFor="upload-description"
            className="text-sm font-medium text-foreground"
          >
            Description{" "}
            <span className="text-muted-foreground font-normal">
              (optional)
            </span>
          </Label>
          <Textarea
            id="upload-description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Describe the track, photo, or video..."
            rows={3}
            className="bg-card border-border text-foreground placeholder:text-muted-foreground focus:border-primary resize-none"
            data-ocid="upload-description"
          />
        </div>

        {/* Release Date + Duration */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="flex flex-col gap-2">
            <Label
              htmlFor="upload-release-date"
              className="text-sm font-medium text-foreground"
            >
              Release Date{" "}
              <span className="text-muted-foreground font-normal">
                (optional)
              </span>
            </Label>
            <Input
              id="upload-release-date"
              type="date"
              value={releaseDate}
              onChange={(e) => setReleaseDate(e.target.value)}
              className="bg-card border-border text-foreground focus:border-primary"
              data-ocid="upload-release-date"
            />
          </div>
          {isAudio && (
            <div className="flex flex-col gap-2">
              <Label
                htmlFor="upload-duration"
                className="text-sm font-medium text-foreground"
              >
                Duration (seconds){" "}
                <span className="text-muted-foreground font-normal">
                  (optional)
                </span>
              </Label>
              <Input
                id="upload-duration"
                type="number"
                min={1}
                value={duration}
                onChange={(e) => setDuration(e.target.value)}
                placeholder="e.g. 252"
                className="bg-card border-border text-foreground placeholder:text-muted-foreground focus:border-primary"
                data-ocid="upload-duration"
              />
            </div>
          )}
        </div>

        {/* Media File */}
        <div className="flex flex-col gap-2">
          <Label className="text-sm font-medium text-foreground">
            Media File <span className="text-destructive">*</span>
          </Label>
          <FileDrop
            label={
              contentType === "photo"
                ? "PNG, JPG, WEBP up to 50 MB"
                : contentType === "video"
                  ? "MP4, MOV, WEBM up to 500 MB"
                  : "MP3, WAV, FLAC up to 100 MB"
            }
            accept={mediaAccept}
            value={mediaPreview}
            onChange={handleMediaChange}
            onClear={() => {
              setMediaFile(null);
              setMediaPreview(null);
            }}
            ocid="upload-media-file"
          />
        </div>

        {/* Cover Art — audio only */}
        {isAudio && (
          <div className="flex flex-col gap-2">
            <Label className="text-sm font-medium text-foreground">
              Cover Art{" "}
              <span className="text-muted-foreground font-normal">
                (optional)
              </span>
            </Label>
            <FileDrop
              label="PNG, JPG, WEBP — square image recommended"
              accept="image/*"
              value={coverPreview}
              onChange={handleCoverChange}
              onClear={() => setCoverPreview(null)}
              ocid="upload-cover-art"
            />
          </div>
        )}

        {/* Actions */}
        <div className="flex items-center gap-4 pt-2">
          <Button
            type="submit"
            disabled={uploading || !title.trim() || !mediaFile}
            className="bg-primary text-primary-foreground hover:bg-primary/80 disabled:opacity-50 px-8"
            data-ocid="upload-submit"
          >
            {uploading ? (
              <>
                <div className="w-4 h-4 rounded-full border-2 border-primary-foreground border-t-transparent animate-spin mr-2" />
                Uploading…
              </>
            ) : (
              <>
                <CloudUpload className="w-4 h-4 mr-2" />
                Upload
              </>
            )}
          </Button>
          <Link to="/">
            <Button
              type="button"
              variant="ghost"
              className="text-muted-foreground"
            >
              Cancel
            </Button>
          </Link>
        </div>
      </form>
    </div>
  );
}
