export type ContentType = "song" | "snippet" | "leak" | "photo" | "video";

export type ReleaseType = "album" | "ep" | "single";

export type MemberHandle =
  | "Otrik"
  | "BWTCHR"
  | "CHUCKII"
  | "Nolon"
  | "deathVailCoven";

export interface ContentItem {
  id: string;
  title: string;
  type: ContentType;
  member: MemberHandle;
  description: string;
  mediaUrl: string;
  thumbnailUrl: string;
  releaseDate: string;
  duration?: string;
  views: number;
  releaseId?: string;
}

export interface Release {
  id: string;
  title: string;
  type: ReleaseType;
  member: MemberHandle;
  coverUrl: string;
  releaseDate: string;
  description: string;
  tracklist: Track[];
}

export interface Track {
  id: string;
  title: string;
  duration: string;
  releaseDate: string;
  audioUrl?: string;
  releaseId: string;
  trackNumber: number;
}

export interface Member {
  handle: MemberHandle;
  displayName: string;
  bio: string;
  avatarUrl: string;
  role: string;
  joinedDate: string;
}

export interface ApprovalRequest {
  principal: string;
  handle: string;
  requestedAt: string;
  status: "pending" | "approved" | "rejected";
}

export type NavItem = {
  label: string;
  path: string;
  icon: string;
};
